<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Release extends Model
{
    //
    protected $table = 'releases';
}
