<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\Users\isaac\Documents\Projects\ipm\resources\views/store/product.twig */
class __TwigTemplate_e69cee93fd65c9649978277c86d0babefdef34afe12017b46598431dce78bed9 extends TwigBridge\Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 6
        return "_layout/site.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["pageTitle"] = "Store";
        // line 2
        $context["pageBackLink"] = false;
        // line 3
        $context["backLinkURL"] = "route('index')";
        // line 4
        $context["customFooter"] = true;
        // line 6
        $this->parent = $this->loadTemplate("_layout/site.twig", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/store/product.twig", 6);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 8
    public function block_content($context, array $blocks = [])
    {
        // line 9
        echo "\t<div class=\"background sd-white-back\">
\t\t<div class=\"mobile_content back-white\">
\t\t\t<div class=\"y-scroll-div full_screen_scroll_footer\">
\t\t\t\t<a class=\"cart_link\" href=\"";
        // line 12
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["store::checkout"]);
        echo "\">C</a>
\t\t\t\t<div>
\t\t\t\t\t<div class=\"product-div flex-column\">
\t\t\t\t\t\t<div class=\"product-image-div flex-row\">
\t\t\t\t\t\t\t<div class=\"product-images\">
\t\t\t\t\t\t\t\t";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["images"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
            // line 18
            echo "\t\t\t\t\t\t\t\t\t";
            if (($this->getAttribute($this->getAttribute(($context["images"] ?? null), 0, [], "array"), "id", []) == $this->getAttribute($context["image"], "id", []))) {
                // line 19
                echo "\t\t\t\t\t\t\t\t\t\t<img src=\"";
                echo twig_escape_filter($this->env, ((((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "store/") . $this->getAttribute(($context["product"] ?? null), "type", [])) . "/") . $this->getAttribute($context["image"], "img_link", [])), "html", null, true);
                echo "\" class=\"product-image\" data-image-id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["image"], "id", []), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t";
            } else {
                // line 21
                echo "\t\t\t\t\t\t\t\t\t\t<img src=\"";
                echo twig_escape_filter($this->env, ((((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "store/") . $this->getAttribute(($context["product"] ?? null), "type", [])) . "/") . $this->getAttribute($context["image"], "img_link", [])), "html", null, true);
                echo "\" class=\"product-image hidden-image\" data-image-id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["image"], "id", []), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t";
            }
            // line 23
            echo "\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"product-thumbnails\">
\t\t\t\t\t\t\t\t";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["images"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
            // line 27
            echo "\t\t\t\t\t\t\t\t\t<img src=\"";
            echo twig_escape_filter($this->env, ((((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "store/") . $this->getAttribute(($context["product"] ?? null), "type", [])) . "/") . $this->getAttribute($context["image"], "img_link", [])), "html", null, true);
            echo "\" class=\"product-thumbnail\" data-module=\"thumbnail\" data-image-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["image"], "id", []), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<p class=\"product-name\">";
        // line 31
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "name", []), "html", null, true);
        echo ((($this->getAttribute(($context["product"] ?? null), "type", []) == "cd")) ? (" CD") : (""));
        echo "</p>
\t\t\t\t\t\t<p class=\"product-price\">\$";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "price", []), "html", null, true);
        echo "</p>
\t\t\t\t\t</div>
\t\t\t\t\t<hr class=\"grey-line\">
\t\t\t\t\t";
        // line 35
        if (($context["sold_out"] ?? null)) {
            // line 36
            echo "\t\t\t\t\t\t<div class=\"product-alerts flex-column\">
\t\t\t\t\t\t\t<div class=\"product-alert alert-error\">
\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t\t<b>
\t\t\t\t\t\t\t\t\t\t\t\t<i>SOLD OUT</i></b>
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 41
            if ((($context["held"] ?? null) > 0)) {
                // line 42
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<br>";
                echo twig_escape_filter($this->env, ($context["held"] ?? null), "html", null, true);
                echo " are currently in a cart<br><span style=\"font-size:80%;font-style:italic\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t(Will be released in 2 hours if not purchased)</span>
\t\t\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 46
                echo "\t\t\t\t\t\t\t\t\t\t\t\t<br>Check back soon for restocks!
\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 48
            echo "\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t</i>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"footer product-buttons flex-row\"></div>
\t\t\t\t";
        } else {
            // line 54
            echo "\t\t\t\t\t<div class=\"product-alerts flex-column\">
\t\t\t\t\t\t";
            // line 55
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["alerts"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["alert"]) {
                // line 56
                echo "\t\t\t\t\t\t\t<div class=\"product-alert alert-";
                echo twig_escape_filter($this->env, $this->getAttribute($context["alert"], "type", []), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t<b>
\t\t\t\t\t\t\t\t\t\t<i>";
                // line 59
                echo twig_escape_filter($this->env, $this->getAttribute($context["alert"], "title", []), "html", null, true);
                echo "</b>
\t\t\t\t\t\t\t\t\t</i>
\t\t\t\t\t\t\t\t\t";
                // line 61
                echo twig_escape_filter($this->env, $this->getAttribute($context["alert"], "message", []), "html", null, true);
                echo "</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['alert'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 64
            echo "\t\t\t\t\t</div>

\t\t\t\t\t<hr class=\"grey-line\">
\t\t\t\t\t<div class=\"footer product-buttons flex-row\">
\t\t\t\t\t\t<div class=\"product-quantity-buttons flex-row\">
\t\t\t\t\t\t\t<div onclick=\"incrementQuantity(this.parentElement.children[1],false)\" class=\"flex-column\">
\t\t\t\t\t\t\t\t<p>-</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<input id=\"quantity_input\" type=\"number\" value=\"1\" min=\"1\" max=\"";
            // line 72
            echo twig_escape_filter($this->env, $this->getAttribute(($context["catalog_item"] ?? null), "amount_left", []), "html", null, true);
            echo "\" onchange=\"validateQuantity(this)\">
\t\t\t\t\t\t\t<div onclick=\"incrementQuantity(this.parentElement.children[1],true)\" class=\"flex-column\">
\t\t\t\t\t\t\t\t<p>+</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div onclick=\"addToCart('')\" class=\"product-button flex-row\">
\t\t\t\t\t\t\t<p>Add To Cart</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        // line 82
        echo "\t\t\t\t<hr class=\"grey-line\">
\t\t\t\t<div class=\"details-div\">
\t\t\t\t\t<p class=\"product-description\">";
        // line 84
        echo $this->getAttribute(($context["product"] ?? null), "description", []);
        echo "</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
\t<div class=\"desktop_content checkout_desktop\">
\t\t<img class=\"back_img\" src=\"";
        // line 90
        echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "backgrounds/sd-back-rainbow.png"), "html", null, true);
        echo "\">
\t\t<div class=\"desktop-scroll\">
\t\t\t<div class=\"y-scroll-div product_info_div\">
\t\t\t\t<a class=\"cart_link\" href=\"";
        // line 93
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["store::checkout"]);
        echo "\">C</a>
\t\t\t\t<div class=\"\">
\t\t\t\t\t<div class=\"flex-row horizontal_div\">
\t\t\t\t\t\t<div class=\"product-div flex-column\">
\t\t\t\t\t\t\t<div class=\"product-image-div flex-row\">
\t\t\t\t\t\t\t\t<div class=\"product-images\">
\t\t\t\t\t\t\t\t\t";
        // line 99
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["images"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
            // line 100
            echo "\t\t\t\t\t\t\t\t\t\t";
            if (($this->getAttribute($this->getAttribute(($context["images"] ?? null), 0, [], "array"), "id", []) == $this->getAttribute($context["image"], "id", []))) {
                // line 101
                echo "\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                echo twig_escape_filter($this->env, ((((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "store/") . $this->getAttribute(($context["product"] ?? null), "type", [])) . "/") . $this->getAttribute($context["image"], "img_link", [])), "html", null, true);
                echo "\" class=\"product-image\" data-image-id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["image"], "id", []), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 103
                echo "\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                echo twig_escape_filter($this->env, ((((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "store/") . $this->getAttribute(($context["product"] ?? null), "type", [])) . "/") . $this->getAttribute($context["image"], "img_link", [])), "html", null, true);
                echo "\" class=\"product-image hidden-image\" data-image-id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["image"], "id", []), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t";
            }
            // line 105
            echo "\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 106
        echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"product-thumbnails\">
\t\t\t\t\t\t\t\t\t";
        // line 108
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["images"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
            // line 109
            echo "\t\t\t\t\t\t\t\t\t\t<img src=\"";
            echo twig_escape_filter($this->env, ((((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "/store/") . $this->getAttribute(($context["product"] ?? null), "type", [])) . "/") . $this->getAttribute($context["image"], "img_link", [])), "html", null, true);
            echo "\" class=\"product-thumbnail\" data-module=\"thumbnail\" data-image-id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["image"], "id", []), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 111
        echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"flex-column desktop-product-description-div\">
\t\t\t\t\t\t\t<p class=\"product-name\">";
        // line 115
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "name", []), "html", null, true);
        echo ((($this->getAttribute(($context["product"] ?? null), "type", []) == "cd")) ? (" CD") : (""));
        echo "</p>
\t\t\t\t\t\t\t<p class=\"product-price\">\$";
        // line 116
        echo twig_escape_filter($this->env, $this->getAttribute(($context["product"] ?? null), "price", []), "html", null, true);
        echo "</p>
\t\t\t\t\t\t\t";
        // line 117
        if (($context["sold_out"] ?? null)) {
            // line 118
            echo "\t\t\t\t\t\t\t\t<div class=\"product-alerts flex-column\">
\t\t\t\t\t\t\t\t\t<div class=\"product-alert alert-error\">
\t\t\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t\t<b>
\t\t\t\t\t\t\t\t\t\t\t\t<i>SOLD OUT</i></b>
\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 123
            if ((($context["held"] ?? null) > 0)) {
                // line 124
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<br>";
                echo twig_escape_filter($this->env, ($context["held"] ?? null), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t\t\t\tare in a customer's cart<br><span style=\"font-size:80%;font-style:italic\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t(Will be released in 2 hours if not purchased)</span>
\t\t\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 129
                echo "\t\t\t\t\t\t\t\t\t\t\t\t<br>Check back soon for restocks!
\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 131
            echo "\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        } else {
            // line 135
            echo "\t\t\t\t\t\t\t<div class=\"product-alerts flex-column\">
\t\t\t\t\t\t\t\t";
            // line 136
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["alerts"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["alert"]) {
                // line 137
                echo "\t\t\t\t\t\t\t\t\t<div class=\"product-alert alert-";
                echo twig_escape_filter($this->env, $this->getAttribute($context["alert"], "type", []), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t\t<b>
\t\t\t\t\t\t\t\t\t\t\t\t<i>";
                // line 140
                echo twig_escape_filter($this->env, $this->getAttribute($context["alert"], "title", []), "html", null, true);
                echo "</b>
\t\t\t\t\t\t\t\t\t\t\t</i>
\t\t\t\t\t\t\t\t\t\t\t";
                // line 142
                echo twig_escape_filter($this->env, $this->getAttribute($context["alert"], "message", []), "html", null, true);
                echo "</p>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['alert'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 145
            echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<hr class=\"grey-line\">

\t\t\t\t\t\t\t<div class=\"product-buttons-description flex-row\">
\t\t\t\t\t\t\t\t<div class=\"product-quantity-buttons flex-row\">
\t\t\t\t\t\t\t\t\t<div onclick=\"incrementQuantity(this.parentElement.children[1],false)\" class=\"flex-column\">
\t\t\t\t\t\t\t\t\t\t<p>-</p>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<input id=\"quantity_input_desktop\" type=\"number\" value=\"1\" min=\"1\" max=\"";
            // line 153
            echo twig_escape_filter($this->env, $this->getAttribute(($context["catalog_item"] ?? null), "amount_left", []), "html", null, true);
            echo "\" onchange=\"validateQuantity(this)\">
\t\t\t\t\t\t\t\t\t<div onclick=\"incrementQuantity(this.parentElement.children[1],true)\" class=\"flex-column\">
\t\t\t\t\t\t\t\t\t\t<p>+</p>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"product-button flex-row\" onclick=\"addToCart('_desktop')\">
\t\t\t\t\t\t\t\t\t<p>Add To Cart</p>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<hr class=\"grey-line\">
\t\t\t\t\t\t";
        }
        // line 164
        echo "

\t\t\t\t\t\t<div class=\"details-div\">
\t\t\t\t\t\t\t<p class=\"product-description\">";
        // line 167
        echo $this->getAttribute(($context["product"] ?? null), "description", []);
        echo "</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<hr class=\"grey-line\">

\t\t\t\t\t</div>
\t\t\t\t\t<div>
\t\t\t\t\t\t<div class=\"footer product-buttons flex-row\">
\t\t\t\t\t\t\t<p>© I.E.M.G 2022 | All Rights Reserved</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
\t<script>
\t\tfunction addToCart(string = null) {;
let quantity = document.getElementById('quantity_input' + string).value;
let url = window.location.href.replace('product', 'addtocart') + `?quantity=\${quantity}`;
window.location = url;
}
function validateQuantity(input) {
let newval = parseInt(input.value);

if (newval > input.getAttribute('max')) {
input.value = parseInt(input.getAttribute('max'));
} else if (newval < 1) {
input.value = 1;
}
}
function incrementQuantity(input, adding) {
let newval = parseInt(input.value);
if (adding) {
newval = newval + 1;
} else {
newval = newval - 1;
} input.value = newval;
validateQuantity(input)
}
\t</script>
";
    }

    public function getTemplateName()
    {
        return "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/store/product.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  387 => 167,  382 => 164,  368 => 153,  358 => 145,  349 => 142,  344 => 140,  337 => 137,  333 => 136,  330 => 135,  324 => 131,  320 => 129,  311 => 124,  309 => 123,  302 => 118,  300 => 117,  296 => 116,  291 => 115,  285 => 111,  274 => 109,  270 => 108,  266 => 106,  260 => 105,  252 => 103,  244 => 101,  241 => 100,  237 => 99,  228 => 93,  222 => 90,  213 => 84,  209 => 82,  196 => 72,  186 => 64,  177 => 61,  172 => 59,  165 => 56,  161 => 55,  158 => 54,  150 => 48,  146 => 46,  138 => 42,  136 => 41,  129 => 36,  127 => 35,  121 => 32,  116 => 31,  112 => 29,  101 => 27,  97 => 26,  93 => 24,  87 => 23,  79 => 21,  71 => 19,  68 => 18,  64 => 17,  56 => 12,  51 => 9,  48 => 8,  43 => 6,  41 => 4,  39 => 3,  37 => 2,  35 => 1,  29 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% set pageTitle = \"Store\" %}
{% set pageBackLink = false %}
{% set backLinkURL = \"route('index')\" %}
{% set customFooter = true %}

{% extends \"_layout/site.twig\" %}

{% block content %}
\t<div class=\"background sd-white-back\">
\t\t<div class=\"mobile_content back-white\">
\t\t\t<div class=\"y-scroll-div full_screen_scroll_footer\">
\t\t\t\t<a class=\"cart_link\" href=\"{{route('store::checkout')}}\">C</a>
\t\t\t\t<div>
\t\t\t\t\t<div class=\"product-div flex-column\">
\t\t\t\t\t\t<div class=\"product-image-div flex-row\">
\t\t\t\t\t\t\t<div class=\"product-images\">
\t\t\t\t\t\t\t\t{% for image in images %}
\t\t\t\t\t\t\t\t\t{% if images[0].id == image.id %}
\t\t\t\t\t\t\t\t\t\t<img src=\"{{config('links.s3_img_link') ~ 'store/' ~ product.type ~ '/' ~ image.img_link}}\" class=\"product-image\" data-image-id=\"{{image.id}}\">
\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t<img src=\"{{config('links.s3_img_link') ~ 'store/' ~ product.type ~ '/' ~ image.img_link}}\" class=\"product-image hidden-image\" data-image-id=\"{{image.id}}\">
\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"product-thumbnails\">
\t\t\t\t\t\t\t\t{% for image in images %}
\t\t\t\t\t\t\t\t\t<img src=\"{{config('links.s3_img_link') ~  'store/' ~ product.type ~ '/' ~ image.img_link}}\" class=\"product-thumbnail\" data-module=\"thumbnail\" data-image-id=\"{{image.id}}\">
\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<p class=\"product-name\">{{product.name}}{{product.type == 'cd' ? ' CD' : ''}}</p>
\t\t\t\t\t\t<p class=\"product-price\">\${{product.price}}</p>
\t\t\t\t\t</div>
\t\t\t\t\t<hr class=\"grey-line\">
\t\t\t\t\t{% if sold_out %}
\t\t\t\t\t\t<div class=\"product-alerts flex-column\">
\t\t\t\t\t\t\t<div class=\"product-alert alert-error\">
\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t\t<b>
\t\t\t\t\t\t\t\t\t\t\t\t<i>SOLD OUT</i></b>
\t\t\t\t\t\t\t\t\t\t\t\t{% if held > 0 %}
\t\t\t\t\t\t\t\t\t\t\t\t\t<br>{{held}} are currently in a cart<br><span style=\"font-size:80%;font-style:italic\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t(Will be released in 2 hours if not purchased)</span>
\t\t\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t\t\t<br>Check back soon for restocks!
\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t</i>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"footer product-buttons flex-row\"></div>
\t\t\t\t{% else %}
\t\t\t\t\t<div class=\"product-alerts flex-column\">
\t\t\t\t\t\t{% for alert in alerts %}
\t\t\t\t\t\t\t<div class=\"product-alert alert-{{alert.type}}\">
\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t<b>
\t\t\t\t\t\t\t\t\t\t<i>{{alert.title}}</b>
\t\t\t\t\t\t\t\t\t</i>
\t\t\t\t\t\t\t\t\t{{alert.message}}</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t</div>

\t\t\t\t\t<hr class=\"grey-line\">
\t\t\t\t\t<div class=\"footer product-buttons flex-row\">
\t\t\t\t\t\t<div class=\"product-quantity-buttons flex-row\">
\t\t\t\t\t\t\t<div onclick=\"incrementQuantity(this.parentElement.children[1],false)\" class=\"flex-column\">
\t\t\t\t\t\t\t\t<p>-</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<input id=\"quantity_input\" type=\"number\" value=\"1\" min=\"1\" max=\"{{catalog_item.amount_left}}\" onchange=\"validateQuantity(this)\">
\t\t\t\t\t\t\t<div onclick=\"incrementQuantity(this.parentElement.children[1],true)\" class=\"flex-column\">
\t\t\t\t\t\t\t\t<p>+</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div onclick=\"addToCart('')\" class=\"product-button flex-row\">
\t\t\t\t\t\t\t<p>Add To Cart</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t{% endif %}
\t\t\t\t<hr class=\"grey-line\">
\t\t\t\t<div class=\"details-div\">
\t\t\t\t\t<p class=\"product-description\">{{product.description|raw}}</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
\t<div class=\"desktop_content checkout_desktop\">
\t\t<img class=\"back_img\" src=\"{{config('links.s3_img_link') ~  'backgrounds/sd-back-rainbow.png'}}\">
\t\t<div class=\"desktop-scroll\">
\t\t\t<div class=\"y-scroll-div product_info_div\">
\t\t\t\t<a class=\"cart_link\" href=\"{{route('store::checkout')}}\">C</a>
\t\t\t\t<div class=\"\">
\t\t\t\t\t<div class=\"flex-row horizontal_div\">
\t\t\t\t\t\t<div class=\"product-div flex-column\">
\t\t\t\t\t\t\t<div class=\"product-image-div flex-row\">
\t\t\t\t\t\t\t\t<div class=\"product-images\">
\t\t\t\t\t\t\t\t\t{% for image in images %}
\t\t\t\t\t\t\t\t\t\t{% if images[0].id == image.id %}
\t\t\t\t\t\t\t\t\t\t\t<img src=\"{{config('links.s3_img_link') ~  'store/' ~ product.type ~ '/' ~ image.img_link}}\" class=\"product-image\" data-image-id=\"{{image.id}}\">
\t\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t\t<img src=\"{{config('links.s3_img_link') ~  'store/' ~ product.type ~ '/' ~ image.img_link}}\" class=\"product-image hidden-image\" data-image-id=\"{{image.id}}\">
\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"product-thumbnails\">
\t\t\t\t\t\t\t\t\t{% for image in images %}
\t\t\t\t\t\t\t\t\t\t<img src=\"{{config('links.s3_img_link') ~  '/store/' ~ product.type ~ '/' ~ image.img_link}}\" class=\"product-thumbnail\" data-module=\"thumbnail\" data-image-id=\"{{image.id}}\">
\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"flex-column desktop-product-description-div\">
\t\t\t\t\t\t\t<p class=\"product-name\">{{product.name}}{{product.type == 'cd' ? ' CD' : ''}}</p>
\t\t\t\t\t\t\t<p class=\"product-price\">\${{product.price}}</p>
\t\t\t\t\t\t\t{% if sold_out %}
\t\t\t\t\t\t\t\t<div class=\"product-alerts flex-column\">
\t\t\t\t\t\t\t\t\t<div class=\"product-alert alert-error\">
\t\t\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t\t<b>
\t\t\t\t\t\t\t\t\t\t\t\t<i>SOLD OUT</i></b>
\t\t\t\t\t\t\t\t\t\t\t\t{% if held > 0 %}
\t\t\t\t\t\t\t\t\t\t\t\t\t<br>{{held}}
\t\t\t\t\t\t\t\t\t\t\t\t\tare in a customer's cart<br><span style=\"font-size:80%;font-style:italic\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t(Will be released in 2 hours if not purchased)</span>
\t\t\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t\t\t<br>Check back soon for restocks!
\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t<div class=\"product-alerts flex-column\">
\t\t\t\t\t\t\t\t{% for alert in alerts %}
\t\t\t\t\t\t\t\t\t<div class=\"product-alert alert-{{alert.type}}\">
\t\t\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\t\t\t<b>
\t\t\t\t\t\t\t\t\t\t\t\t<i>{{alert.title}}</b>
\t\t\t\t\t\t\t\t\t\t\t</i>
\t\t\t\t\t\t\t\t\t\t\t{{alert.message}}</p>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<hr class=\"grey-line\">

\t\t\t\t\t\t\t<div class=\"product-buttons-description flex-row\">
\t\t\t\t\t\t\t\t<div class=\"product-quantity-buttons flex-row\">
\t\t\t\t\t\t\t\t\t<div onclick=\"incrementQuantity(this.parentElement.children[1],false)\" class=\"flex-column\">
\t\t\t\t\t\t\t\t\t\t<p>-</p>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<input id=\"quantity_input_desktop\" type=\"number\" value=\"1\" min=\"1\" max=\"{{catalog_item.amount_left}}\" onchange=\"validateQuantity(this)\">
\t\t\t\t\t\t\t\t\t<div onclick=\"incrementQuantity(this.parentElement.children[1],true)\" class=\"flex-column\">
\t\t\t\t\t\t\t\t\t\t<p>+</p>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"product-button flex-row\" onclick=\"addToCart('_desktop')\">
\t\t\t\t\t\t\t\t\t<p>Add To Cart</p>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<hr class=\"grey-line\">
\t\t\t\t\t\t{% endif %}


\t\t\t\t\t\t<div class=\"details-div\">
\t\t\t\t\t\t\t<p class=\"product-description\">{{product.description|raw}}</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<hr class=\"grey-line\">

\t\t\t\t\t</div>
\t\t\t\t\t<div>
\t\t\t\t\t\t<div class=\"footer product-buttons flex-row\">
\t\t\t\t\t\t\t<p>© I.E.M.G 2022 | All Rights Reserved</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
\t<script>
\t\tfunction addToCart(string = null) {;
let quantity = document.getElementById('quantity_input' + string).value;
let url = window.location.href.replace('product', 'addtocart') + `?quantity=\${quantity}`;
window.location = url;
}
function validateQuantity(input) {
let newval = parseInt(input.value);

if (newval > input.getAttribute('max')) {
input.value = parseInt(input.getAttribute('max'));
} else if (newval < 1) {
input.value = 1;
}
}
function incrementQuantity(input, adding) {
let newval = parseInt(input.value);
if (adding) {
newval = newval + 1;
} else {
newval = newval - 1;
} input.value = newval;
validateQuantity(input)
}
\t</script>
{% endblock %}
", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/store/product.twig", "");
    }
}
