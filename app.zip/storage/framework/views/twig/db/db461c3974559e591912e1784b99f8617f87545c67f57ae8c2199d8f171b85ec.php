<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layout/adminsite.twig */
class __TwigTemplate_36d80e66c12f9011c0713d1fd82c9354ee3dd8dd1970d0cc72005a9ebd8b06f6 extends TwigBridge\Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<!DOCTYPE html>
";
        // line 2
        ob_start();
        // line 3
        echo "<html lang=\"en\">
<head>
        ";
        // line 5
        $this->loadTemplate("_layout/_snippets/head.twig", "_layout/adminsite.twig", 5)->display($context);
        // line 6
        echo "</head>
<body>
    <header>
        ";
        // line 9
        $this->loadTemplate("index/_snippets/_adminnav.twig", "_layout/adminsite.twig", 9)->display($context);
        // line 10
        echo "    </header>
    <div class = \"layout\">
        <main>
            ";
        // line 13
        $this->displayBlock('content', $context, $blocks);
        // line 15
        echo "        </main>
    </div>
</body>
<footer>
";
        // line 19
        $this->loadTemplate("_layout/_snippets/footer.twig", "_layout/adminsite.twig", 19)->display($context);
        // line 20
        echo "</footer>
</html>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 13
    public function block_content($context, array $blocks = [])
    {
        // line 14
        echo "            ";
    }

    public function getTemplateName()
    {
        return "_layout/adminsite.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 14,  71 => 13,  64 => 20,  62 => 19,  56 => 15,  54 => 13,  49 => 10,  47 => 9,  42 => 6,  40 => 5,  36 => 3,  34 => 2,  31 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
{% spaceless %}
<html lang=\"en\">
<head>
        {% include \"_layout/_snippets/head.twig\" %}
</head>
<body>
    <header>
        {% include \"index/_snippets/_adminnav.twig\" %}
    </header>
    <div class = \"layout\">
        <main>
            {% block content %}
            {% endblock %}
        </main>
    </div>
</body>
<footer>
{% include \"_layout/_snippets/footer.twig\" %}
</footer>
</html>
{% endspaceless %}
", "_layout/adminsite.twig", "");
    }
}
