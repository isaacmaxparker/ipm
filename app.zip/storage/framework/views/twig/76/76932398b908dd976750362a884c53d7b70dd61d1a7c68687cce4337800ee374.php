<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\Users\isaac\Documents\Projects\ipm\resources\views/store/catalog.twig */
class __TwigTemplate_fe9feeae86b081ab3fabcaeafc618e2dd5263d7fec3d7249677b7e05b5d2ea89 extends TwigBridge\Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "_layout/site.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["pageTitle"] = "Store";
        // line 3
        $this->parent = $this->loadTemplate("_layout/site.twig", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/store/catalog.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        // line 6
        echo "<div class=\"background sd-back\">
    <div class=\"mobile_content fullscreen\">
        <div class=\"y-scroll-div back-white\">
            <div class=\"shop_catalog_grid\">
                ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["products"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 11
            echo "                    <div class=\"product_tile\">
                        <a href=\"";
            // line 12
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["store::product", [0 => $this->getAttribute($context["product"], "prod_id", [])]]);
            echo "\" class=\"first-child\">
                            <img src=\"";
            // line 13
            echo call_user_func_array($this->env->getFunction('asset')->getCallable(), [((("img/store/" . $this->getAttribute($context["product"], "type", [])) . "/") . $this->getAttribute($context["product"], "img_link", []))]);
            echo "\">
                            <p>";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "name", []), "html", null, true);
            echo ((($this->getAttribute($context["product"], "type", []) == "tshirt")) ? (" Shirt") : (""));
            echo "</p>
                        </a>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/store/catalog.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  77 => 18,  66 => 14,  62 => 13,  58 => 12,  55 => 11,  51 => 10,  45 => 6,  42 => 5,  37 => 3,  35 => 1,  29 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% set pageTitle = \"Store\" %}

{% extends \"_layout/site.twig\" %}

{% block content %}
<div class=\"background sd-back\">
    <div class=\"mobile_content fullscreen\">
        <div class=\"y-scroll-div back-white\">
            <div class=\"shop_catalog_grid\">
                {% for product in products %}
                    <div class=\"product_tile\">
                        <a href=\"{{route('store::product',[product.prod_id])}}\" class=\"first-child\">
                            <img src=\"{{asset('img/store/' ~ product.type ~ '/' ~ product.img_link)}}\">
                            <p>{{product.name}}{{product.type == 'tshirt' ? ' Shirt' : ''}}</p>
                        </a>
                    </div>
                {% endfor %}
            </div>
        </div>
    </div>
</div>
{% endblock %}", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/store/catalog.twig", "");
    }
}
