<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\Users\isaac\Documents\Projects\ipm\resources\views/admin/releases/list.twig */
class __TwigTemplate_eb36caeb20d131355f47d0640a313441979fbc78997658d3cd0c269bab6446ce extends TwigBridge\Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "_layout/adminsite.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["pageTitle"] = "Releases";
        // line 3
        $this->parent = $this->loadTemplate("_layout/adminsite.twig", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/admin/releases/list.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        // line 6
        echo "\t<div class=\"header_content slowload\" data-module=\"slowload\">
\t\t<div class=\"back_img\"><img src=\"";
        // line 7
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]), "html", null, true);
        echo "releases/backgrounds/cn-back.png\"></div>
\t\t<div class=\"admin_div flex-column\">
            <div class=\"action_buttons\">
                <a class=\"button\" href=\"";
        // line 10
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["admin::newrelease"]);
        echo "\">+ Add New</a>
            </div>
            <div class=\"table\">
                <table class=\"x-scroll-div y-scroll-div\">
                    <tbody>
                    <tr>
                        <th>Name</th>
                        <th>Release Date</th>
                        <th>Number of Songs</th>
                        <th>Actions</th>
                    </tr>
                        ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["rows"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 22
            echo "                        
                            <tr class=\"";
            // line 23
            echo (((twig_date_format_filter($this->env, $this->getAttribute($context["row"], "date", []), "Y-m-d") > twig_date_format_filter($this->env, "now", "Y-m-d"))) ? ("unreleased") : (""));
            echo "\">
                                <td>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["row"], "name", []), "html", null, true);
            echo (((twig_date_format_filter($this->env, $this->getAttribute($context["row"], "date", []), "Y-m-d") > twig_date_format_filter($this->env, "now", "Y-m-d"))) ? (" (unreleased)") : (""));
            echo "</td>
                                <td>";
            // line 25
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["row"], "date", []), "F jS Y"), "html", null, true);
            echo "</td>
                                <td>";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["row"], "song_count", []), "html", null, true);
            echo "</td>
                                <td>
                                ";
            // line 28
            if ((twig_date_format_filter($this->env, $this->getAttribute($context["row"], "date", []), "Y-m-d") < twig_date_format_filter($this->env, "now", "Y-m-d"))) {
                // line 29
                echo "                                    <a href=\"";
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["music::release", [0 => $this->getAttribute($context["row"], "id", [])]]);
                echo "\" target=\"_blank\"><button>View</button></a>
                                ";
            }
            // line 31
            echo "                                    <a href=\"";
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["admin::editrelease", [0 => $this->getAttribute($context["row"], "id", [])]]);
            echo "\"><button>Edit</button></a>
                                    <button>Delete</button>
                                </td>

                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "                    </tbody>
                </table>
            </div>
\t\t</div>
\t";
    }

    public function getTemplateName()
    {
        return "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/admin/releases/list.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 37,  101 => 31,  95 => 29,  93 => 28,  88 => 26,  84 => 25,  79 => 24,  75 => 23,  72 => 22,  68 => 21,  54 => 10,  48 => 7,  45 => 6,  42 => 5,  37 => 3,  35 => 1,  29 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% set pageTitle = \"Releases\" %}

{% extends \"_layout/adminsite.twig\" %}

{% block content %}
\t<div class=\"header_content slowload\" data-module=\"slowload\">
\t\t<div class=\"back_img\"><img src=\"{{config('links.s3_img_link')}}releases/backgrounds/cn-back.png\"></div>
\t\t<div class=\"admin_div flex-column\">
            <div class=\"action_buttons\">
                <a class=\"button\" href=\"{{route('admin::newrelease')}}\">+ Add New</a>
            </div>
            <div class=\"table\">
                <table class=\"x-scroll-div y-scroll-div\">
                    <tbody>
                    <tr>
                        <th>Name</th>
                        <th>Release Date</th>
                        <th>Number of Songs</th>
                        <th>Actions</th>
                    </tr>
                        {% for row in rows %}
                        
                            <tr class=\"{{row.date|date(\"Y-m-d\") > \"now\"|date(\"Y-m-d\") ? 'unreleased'}}\">
                                <td>{{row.name}}{{row.date|date(\"Y-m-d\") > \"now\"|date(\"Y-m-d\") ? ' (unreleased)'}}</td>
                                <td>{{row.date |date(\"F jS Y\")}}</td>
                                <td>{{row.song_count}}</td>
                                <td>
                                {% if row.date|date(\"Y-m-d\") < \"now\"|date(\"Y-m-d\") %}
                                    <a href=\"{{route('music::release',[row.id])}}\" target=\"_blank\"><button>View</button></a>
                                {% endif %}
                                    <a href=\"{{route('admin::editrelease',[row.id])}}\"><button>Edit</button></a>
                                    <button>Delete</button>
                                </td>

                            </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
\t\t</div>
\t{% endblock %}
", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/admin/releases/list.twig", "");
    }
}
