<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\Users\isaac\Documents\Projects\ipm\resources\views/music/release.twig */
class __TwigTemplate_0d75547e3b6daf61ce8091439f91ed689a2006a58bc08accba26f4cf49f42b78 extends TwigBridge\Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layout/site.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 2
        $context["pageTitle"] = $this->getAttribute(($context["release"] ?? null), "title", []);
        // line 3
        $context["customFooter"] = true;
        // line 1
        $this->parent = $this->loadTemplate("_layout/site.twig", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/music/release.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        // line 6
        echo "    <div class=\"background ";
        ((($this->getAttribute(($context["release"] ?? null), "background_type", []) == "image")) ? (print (twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "back_img_link", []), "html", null, true))) : (print ("")));
        echo "\">
    ";
        // line 7
        if (($this->getAttribute(($context["release"] ?? null), "background_type", []) == "video")) {
            // line 8
            echo "        <video id=\"gallery_video\" autoplay loop muted playsinline class=\"";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
            echo "-border invisible slowload\">
            <source src=\"";
            // line 9
            echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/gallery/") . $this->getAttribute(($context["release"] ?? null), "back_img_link", [])), "html", null, true);
            echo ".webm\" type=\"video/webm\">
            <source src=\"";
            // line 10
            echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/gallery/") . $this->getAttribute(($context["release"] ?? null), "back_img_link", [])), "html", null, true);
            echo ".mp4\" type=\"video/mp4\">
        </video>
    ";
        } else {
            // line 13
            echo "    <div class=\"back_img\"><img src=\"";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]), "html", null, true);
            echo "releases/backgrounds/";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "back_img_link", []), "html", null, true);
            echo "\"></div>
    ";
        }
        // line 15
        echo "    </div>
\t<div class=\"mobile_content\">
\t\t<div id=\"main-content\" class=\"main-content \">
\t\t\t<div class=\"scroll-view\">
\t\t\t\t<div class=\"albumContainer\">
\t\t\t\t\t<div class=\"albumArtContainer\">
\t\t\t\t\t\t<img id=\"albumartImg\" data-js=\"lowresimageload\" class=\"albumArtImg\" src=\"";
        // line 21
        echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/album_arts/") . $this->getAttribute(($context["release"] ?? null), "img_link", [])), "html", null, true);
        echo "\">
\t\t\t\t\t</div>
\t\t\t\t\t<div id=\"previewsDiv\" class=\"previews\">
\t\t\t\t\t\t";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["songs"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["song"]) {
            // line 25
            echo "\t\t\t\t\t\t\t<div class=\"songPreviewDiv\">
\t\t\t\t\t\t\t\t<div class=\"songPreviewButtonsDiv ";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
            echo "-border\" data-module=\"audio\">
\t\t\t\t\t\t\t\t\t<div style=\"display: none;\">
\t\t\t\t\t\t\t\t\t\t<audio controls=\"\" class=\"songPreviewAudio\">
\t\t\t\t\t\t\t\t\t\t\t<source src=\"";
            // line 29
            echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_audio_link"]) . "audio/previews/") . $this->getAttribute($context["song"], "audio_link", [])), "html", null, true);
            echo "\" type=\"audio/mpeg\">
\t\t\t\t\t\t\t\t\t\t\tYour browser does not support the audio element.
\t\t\t\t\t\t\t\t\t\t</audio>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<svg class=\"playingCircle hidden ";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
            echo "-stroke\" viewbox=\"0 0 100 100\">
\t\t\t\t\t\t\t\t\t\t<circle cx=\"50\" cy=\"50\" r=\"40\"></circle>
\t\t\t\t\t\t\t\t\t</svg>
\t\t\t\t\t\t\t\t\t<div class=\"songPreviewButton songPreviewPlayButton ";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
            echo "-fill\">
\t\t\t\t\t\t\t\t\t\t<svg x=\"0px\" y=\"0px\" viewbox=\"0 0 17.804 17.804\" style=\"enable-background:new 0 0 17.804 17.804;\" xml:space=\"preserve\">
\t\t\t\t\t\t\t\t\t\t\t<path d=\"M2.067,0.043C2.21-0.028,2.372-0.008,2.493,0.085l13.312,8.503c0.094,0.078,0.154,0.191,0.154,0.313    c0,0.12-0.061,0.237-0.154,0.314L2.492,17.717c-0.07,0.057-0.162,0.087-0.25,0.087l-0.176-0.04    c-0.136-0.065-0.222-0.207-0.222-0.361V0.402C1.844,0.25,1.93,0.107,2.067,0.043z\"></path>
\t\t\t\t\t\t\t\t\t\t</svg>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"songPreviewButton songPreviewStopButton ";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
            echo "-fill hidden\">
\t\t\t\t\t\t\t\t\t\t<svg x=\"0px\" y=\"0px\" viewbox=\"0 0 10.334 10.334\" style=\"enable-background:new 0 0 10.334 10.334;\" xml:space=\"preserve\">
\t\t\t\t\t\t\t\t\t\t\t<path d=\"M10.333,9.816c0,0.285-0.231,0.518-0.517,0.518H0.517C0.233,10.334,0,10.102,0,9.816V0.517   C0,0.232,0.231,0,0.517,0h9.299c0.285,0,0.517,0.231,0.517,0.517V9.816z\"></path>
\t\t\t\t\t\t\t\t\t\t</svg>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"songPreviewTextDiv ";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
            echo "-text\">
\t\t\t\t\t\t\t\t\t<div class=\"songPreviewTrackNumber\">";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($context["song"], "track_number", []), "html", null, true);
            echo ".</div>
\t\t\t\t\t\t\t\t\t";
            // line 49
            if ((twig_length_filter($this->env, $this->getAttribute($context["song"], "title", [])) > 15)) {
                // line 50
                echo "\t\t\t\t\t\t\t\t\t\t<div class=\"songPreviewTitle\" style=\"font-size:75%;\">";
                echo $this->getAttribute($context["song"], "title", []);
                echo "</div>
\t\t\t\t\t\t\t\t\t";
            } else {
                // line 52
                echo "\t\t\t\t\t\t\t\t\t\t<div class=\"songPreviewTitle\" style=\"\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["song"], "title", []), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t\t";
            }
            // line 54
            echo "
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['song'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "\t\t\t\t\t</div>
\t\t\t\t\t";
        // line 59
        if ($this->getAttribute(($context["release"] ?? null), "youtube_link", [])) {
            // line 60
            echo "\t\t\t\t\t\t<div id=\"youtube_cont_id\">
\t\t\t\t\t\t\t<iframe width=\"95%\" height=\"100%\" src=\"";
            // line 61
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "youtube_link", []), "html", null, true);
            echo "\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen=\"\"></iframe>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 64
        echo "
\t\t\t\t\t";
        // line 65
        if (($context["other_releases"] ?? null)) {
            // line 66
            echo "\t\t\t\t\t\t<hr style=\"margin-top:0px\">
\t\t\t\t\t\t<div id=\"other_releases_div\">
\t\t\t\t\t\t\t<div id=\"previoustext\" class=\"listenText\" style=\"justify-self: flex-start;margin-bottom: 20px;\">Other Releases</div>
\t\t\t\t\t\t\t<div class=\"x-scroll-container\">
\t\t\t\t\t\t\t\t<div id=\"other_releases_grid\">
\t\t\t\t\t\t\t\t\t";
            // line 71
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["other_releases"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 72
                echo "\t\t\t\t\t\t\t\t\t\t<div class=\"other_release_grid_item\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 73
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["music::release", [0 => $this->getAttribute($context["item"], "id", [])]]);
                echo "\"><img src=\"";
                echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/album_arts/") . $this->getAttribute($context["item"], "img_link", [])), "html", null, true);
                echo "\"></a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 76
            echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<hr style=\"margin-top:0px; margin-bottom:20px;\">
\t\t\t\t\t";
        }
        // line 81
        echo "\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div id=\"storesDiv\" class=\"storesDiv ";
        // line 83
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
        echo "-dark-back\">
\t\t\t\t<div id=\"listentext\" class=\"listenText ";
        // line 84
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
        echo "-text\" style=\"justify-self: flex-start;margin-bottom: 20px;\">Listen on</div>
\t\t\t\t<div class=\"x-scroll-container\">
\t\t\t\t\t<div id=\"storeLinksDiv\" class=\"storesList\">
\t\t\t\t\t\t<div class=\"storeLink\">
\t\t\t\t\t\t\t<a class=\"storeImage\" href=\"";
        // line 88
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "spotify_link", []), "html", null, true);
        echo "\" target=\"_blank\">
\t\t\t\t\t\t\t\t<img style=\"width:100%\" src=\"";
        // line 89
        echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/store_logos/spotify.png"), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<div class=\"storeText\">Spotify</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"storeLink\">
\t\t\t\t\t\t\t<a class=\"storeImage\" href=\"";
        // line 95
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "itunes_link", []), "html", null, true);
        echo "\" target=\"_blank\">
\t\t\t\t\t\t\t\t<img style=\"width:100%\" src=\"";
        // line 96
        echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/store_logos/appleMusic.png"), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<div class=\"storeText\">Apple Music</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"storeLink\">
\t\t\t\t\t\t\t<a class=\"storeImage\" href=\"";
        // line 102
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "youtube_music_link", []), "html", null, true);
        echo "\" target=\"_blank\">
\t\t\t\t\t\t\t\t<img style=\"width:100%\" src=\"";
        // line 103
        echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/store_logos/youtubeMusic.png"), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<div class=\"storeText\">Youtube</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"storeLink\">
\t\t\t\t\t\t\t<a class=\"storeImage\" href=\"";
        // line 109
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "amazon_link", []), "html", null, true);
        echo "\" target=\"_blank\">
\t\t\t\t\t\t\t\t<img style=\"width:100%\" src=\"";
        // line 110
        echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/store_logos/amazon.png"), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<div class=\"storeText\">Amazon Music</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"storeLink\">
\t\t\t\t\t\t\t<a class=\"storeImage\" href=\"";
        // line 116
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "distrokid_link", []), "html", null, true);
        echo "\" target=\"_blank\">
\t\t\t\t\t\t\t\t<svg style=\"width:100%\" class=\"";
        // line 117
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
        echo "-fill\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" id=\"Layer_1\" x=\"0px\" y=\"0px\" viewbox=\"0 0 330 330\" xml:space=\"preserve\">
\t\t\t\t\t\t\t\t\t<path id=\"XMLID_22_\" d=\"M165,0C74.019,0,0,74.019,0,165s74.019,165,165,165s165-74.019,165-165S255.981,0,165,0z M85,190  c-13.785,0-25-11.215-25-25s11.215-25,25-25s25,11.215,25,25S98.785,190,85,190z M165,190c-13.785,0-25-11.215-25-25  s11.215-25,25-25s25,11.215,25,25S178.785,190,165,190z M245,190c-13.785,0-25-11.215-25-25s11.215-25,25-25  c13.785,0,25,11.215,25,25S258.785,190,245,190z\"></path>
\t\t\t\t\t\t\t\t</svg>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<div class=\"storeText\">More</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div style=\"width:5px;margin-right:10px\">&nbsp;</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t    </div>
    </div>
    <div class=\"desktop_content\" data-module=\"slowload\">
        <div id=\"main-content\" class=\"main-content-release-desktop ";
        // line 130
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "back_img_link", []), "html", null, true);
        echo " scroll-x-view\">
            <div class=\"left-side-release\">
                <div class=\"albumArtContainer\">
                    <img id=\"albumartImg\" data-js=\"lowresimageload\" class=\"albumArtImg\" src=\"";
        // line 133
        echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/album_arts/") . $this->getAttribute(($context["release"] ?? null), "img_link", [])), "html", null, true);
        echo "\">
                    <div class=\"storeText\">";
        // line 134
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "title", []), "html", null, true);
        echo "</div>
                    <div class=\"storeText ";
        // line 135
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
        echo "-text\" style=\"font-size:100%;margin:10px;\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "subtitle", []), "html", null, true);
        echo "</div>
                </div>
                ";
        // line 137
        if ($this->getAttribute(($context["release"] ?? null), "description", [])) {
            // line 138
            echo "                <div class=\"left-side-description\">
                    <p class=\"left-side-description-title ";
            // line 139
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
            echo "-text\">About The Album:</p>
                    <p>";
            // line 140
            echo $this->getAttribute(($context["release"] ?? null), "description", []);
            echo "</p>
                    <p>© ";
            // line 141
            echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute(($context["release"] ?? null), "release_date", []), 0, 4), "html", null, true);
            echo " Isaac McDougal, IEMG LLC</p>
                </div>
                ";
        }
        // line 144
        echo "            </div>
            <div class=\"middle-side-release\">
                <div class=\"scroll-y-view scroll\">
                    <div id=\"previewsDiv\" class=\"previews\">
                        ";
        // line 148
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["songs"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["song"]) {
            // line 149
            echo "                            <div class=\"songPreviewDiv\">
                                <div class=\"songPreviewButtonsDiv ";
            // line 150
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
            echo "-border\" data-module=\"audio\">
                                    <div style=\"display: none;\">
                                        <audio controls=\"\" class=\"songPreviewAudio\">
                                            <source src=\"";
            // line 153
            echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_audio_link"]) . "audio/previews/") . $this->getAttribute($context["song"], "audio_link", [])), "html", null, true);
            echo "\" type=\"audio/mpeg\">
                                            Your browser does not support the audio element.
                                        </audio>
                                    </div>
                                    <svg class=\"playingCircle hidden ";
            // line 157
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
            echo "-stroke\" viewbox=\"0 0 100 100\">
                                        <circle cx=\"50\" cy=\"50\" r=\"40\"></circle>
                                    </svg>
                                    <div class=\"songPreviewButton songPreviewPlayButton ";
            // line 160
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
            echo "-fill\">
                                        <svg x=\"0px\" y=\"0px\" viewbox=\"0 0 17.804 17.804\" style=\"enable-background:new 0 0 17.804 17.804;\" xml:space=\"preserve\">
                                            <path d=\"M2.067,0.043C2.21-0.028,2.372-0.008,2.493,0.085l13.312,8.503c0.094,0.078,0.154,0.191,0.154,0.313    c0,0.12-0.061,0.237-0.154,0.314L2.492,17.717c-0.07,0.057-0.162,0.087-0.25,0.087l-0.176-0.04    c-0.136-0.065-0.222-0.207-0.222-0.361V0.402C1.844,0.25,1.93,0.107,2.067,0.043z\"></path>
                                        </svg>
                                    </div>
                                    <div class=\"songPreviewButton songPreviewStopButton ";
            // line 165
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
            echo "-fill hidden\">
                                        <svg x=\"0px\" y=\"0px\" viewbox=\"0 0 10.334 10.334\" style=\"enable-background:new 0 0 10.334 10.334;\" xml:space=\"preserve\">
                                            <path d=\"M10.333,9.816c0,0.285-0.231,0.518-0.517,0.518H0.517C0.233,10.334,0,10.102,0,9.816V0.517   C0,0.232,0.231,0,0.517,0h9.299c0.285,0,0.517,0.231,0.517,0.517V9.816z\"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class=\"songPreviewTextDiv ";
            // line 171
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
            echo "-text\">
                                    <div class=\"songPreviewTrackNumber\">";
            // line 172
            echo twig_escape_filter($this->env, $this->getAttribute($context["song"], "track_number", []), "html", null, true);
            echo ".</div>
                                    ";
            // line 173
            if ((twig_length_filter($this->env, $this->getAttribute($context["song"], "title", [])) > 15)) {
                // line 174
                echo "                                        <div class=\"songPreviewTitle\" style=\"font-size:75%;\">";
                echo $this->getAttribute($context["song"], "title", []);
                echo "</div>
                                    ";
            } else {
                // line 176
                echo "                                        <div class=\"songPreviewTitle\" style=\"\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["song"], "title", []), "html", null, true);
                echo "</div>
                                    ";
            }
            // line 178
            echo "
                                </div>
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['song'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 182
        echo "                    </div>
                </div>
                <div id=\"storesDiv\" class=\"storesDiv\">
                        <div id=\"listentext\" class=\"listenText ";
        // line 185
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
        echo "-text\" style=\"justify-self: flex-start;margin-bottom: 20px;\">Listen on</div>
                        <div class=\"scroll-y-view\" style=\"width:90%;\">
                            <div id=\"storeLinksDiv\" class=\"storesList\">
                                <div class=\"storeLink\">
                                    <a class=\"storeImage\" href=\"";
        // line 189
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "spotify_link", []), "html", null, true);
        echo "\" target=\"_blank\">
                                        <img style=\"width:100%\" src=\"";
        // line 190
        echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/store_logos/spotify.png"), "html", null, true);
        echo "\">
                                    </a>
                                     <a class=\"storeText ";
        // line 192
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
        echo "-text\" href=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "spotify_link", []), "html", null, true);
        echo "\" target=\"_blank\">Spotify</a>
                                </div>

                                <div class=\"storeLink\">
                                    <a class=\"storeImage\" href=\"";
        // line 196
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "itunes_link", []), "html", null, true);
        echo "\" target=\"_blank\">
                                        <img style=\"width:100%\" src=\"";
        // line 197
        echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/store_logos/appleMusic.png"), "html", null, true);
        echo "\">
                                    </a>
                                    <a class=\"storeText ";
        // line 199
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
        echo "-text\" href=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "itunes_link", []), "html", null, true);
        echo "\" target=\"_blank\">Apple Music</a>
                                </div>

                                <div class=\"storeLink\">
                                    <a class=\"storeImage\" href=\"";
        // line 203
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "youtube_music_link", []), "html", null, true);
        echo "\" target=\"_blank\">
                                        <img style=\"width:100%\" src=\"";
        // line 204
        echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/store_logos/youtubeMusic.png"), "html", null, true);
        echo "\">
                                    </a>
                                    <a class=\"storeText ";
        // line 206
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
        echo "-text\" href=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "youtube_music_link", []), "html", null, true);
        echo "\" target=\"_blank\">Youtube Music</a>
                                </div>

                                <div class=\"storeLink\">
                                    <a class=\"storeImage\" href=\"";
        // line 210
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "amazon_link", []), "html", null, true);
        echo "\" target=\"_blank\">
                                        <img style=\"width:100%\" src=\"";
        // line 211
        echo twig_escape_filter($this->env, (call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/store_logos/amazon.png"), "html", null, true);
        echo "\">
                                    </a>
                                    <a class=\"storeText ";
        // line 213
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
        echo "-text\" href=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "amazon_link", []), "html", null, true);
        echo "\" target=\"_blank\">Amazon</a>
                                </div>

                                <div class=\"storeLink\">
                                    <a class=\"storeImage\" href=\"";
        // line 217
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "distrokid_link", []), "html", null, true);
        echo "\" target=\"_blank\">
                                        <svg style=\"width:100%\" class=\"";
        // line 218
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
        echo "-fill\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" id=\"Layer_1\" x=\"0px\" y=\"0px\" viewbox=\"0 0 330 330\" xml:space=\"preserve\">
                                            <path id=\"XMLID_22_\" d=\"M165,0C74.019,0,0,74.019,0,165s74.019,165,165,165s165-74.019,165-165S255.981,0,165,0z M85,190  c-13.785,0-25-11.215-25-25s11.215-25,25-25s25,11.215,25,25S98.785,190,85,190z M165,190c-13.785,0-25-11.215-25-25  s11.215-25,25-25s25,11.215,25,25S178.785,190,165,190z M245,190c-13.785,0-25-11.215-25-25s11.215-25,25-25  c13.785,0,25,11.215,25,25S258.785,190,245,190z\"></path>
                                        </svg>
                                    </a>
                                    <a class=\"storeText ";
        // line 222
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
        echo "-text\" href=\"";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "distrokid_link", []), "html", null, true);
        echo "\" target=\"_blank\">More</a>
                                </div>
                                <div style=\"width:5px;margin-right:10px\">&nbsp;</div>
                            </div>
                    </div>
                </div>
            </div>
            <div class=\"right-side-release\">
                ";
        // line 230
        if ($this->getAttribute(($context["release"] ?? null), "youtube_link", [])) {
            // line 231
            echo "                    <div id=\"youtube_cont_id\">
                        <iframe width=\"100%\" height=\"100%\" src=\"";
            // line 232
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "youtube_link", []), "html", null, true);
            echo "\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen=\"\"></iframe>
                    </div>
                ";
        } else {
            // line 235
            echo "                    <div id=\"youtube_cont_id\">
                        <video id=\"gallery_video\" autoplay loop muted playsinline class=\"";
            // line 236
            echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
            echo "-border invisible slowload\"  width=\"100%\" height=\"100%\">
                            <source src=\"";
            // line 237
            echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/gallery/") . $this->getAttribute(($context["release"] ?? null), "gallery_img_link", [])), "html", null, true);
            echo ".webm\" type=\"video/webm\">
                            <source src=\"";
            // line 238
            echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/gallery/") . $this->getAttribute(($context["release"] ?? null), "gallery_img_link", [])), "html", null, true);
            echo ".mp4\" type=\"video/mp4\">
                        </video>
                    </div>
                ";
        }
        // line 242
        echo "                ";
        if (($context["other_releases"] ?? null)) {
            // line 243
            echo "                    <div id=\"other_releases_div\">
                        <div id=\"previoustext\" class=\"listenText\" style=\"justify-self: flex-start;margin-bottom: 20px;\">Other Releases</div>
                        <div class=\"x-scroll-container scroll\">
                            <div id=\"other_releases_grid\">
                                ";
            // line 247
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["other_releases"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 248
                echo "                                    <div class=\"other_release_grid_item\">
                                        <a href=\"";
                // line 249
                echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["music::release", [0 => $this->getAttribute($context["item"], "id", [])]]);
                echo "\"><img src=\"";
                echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/album_arts/") . $this->getAttribute($context["item"], "img_link", [])), "html", null, true);
                echo "\" class=\"invisible visible\" onload=\"this.classList.remove('invisible')\"></a>
                                    </div>
                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 252
            echo "                            </div>
                        </div>
                    </div>
                ";
        }
        // line 256
        echo "        </div>
    </div>
\t";
    }

    public function getTemplateName()
    {
        return "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/music/release.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  593 => 256,  587 => 252,  576 => 249,  573 => 248,  569 => 247,  563 => 243,  560 => 242,  553 => 238,  549 => 237,  545 => 236,  542 => 235,  536 => 232,  533 => 231,  531 => 230,  518 => 222,  511 => 218,  507 => 217,  498 => 213,  493 => 211,  489 => 210,  480 => 206,  475 => 204,  471 => 203,  462 => 199,  457 => 197,  453 => 196,  444 => 192,  439 => 190,  435 => 189,  428 => 185,  423 => 182,  414 => 178,  408 => 176,  402 => 174,  400 => 173,  396 => 172,  392 => 171,  383 => 165,  375 => 160,  369 => 157,  362 => 153,  356 => 150,  353 => 149,  349 => 148,  343 => 144,  337 => 141,  333 => 140,  329 => 139,  326 => 138,  324 => 137,  317 => 135,  313 => 134,  309 => 133,  303 => 130,  287 => 117,  283 => 116,  274 => 110,  270 => 109,  261 => 103,  257 => 102,  248 => 96,  244 => 95,  235 => 89,  231 => 88,  224 => 84,  220 => 83,  216 => 81,  209 => 76,  198 => 73,  195 => 72,  191 => 71,  184 => 66,  182 => 65,  179 => 64,  173 => 61,  170 => 60,  168 => 59,  165 => 58,  156 => 54,  150 => 52,  144 => 50,  142 => 49,  138 => 48,  134 => 47,  125 => 41,  117 => 36,  111 => 33,  104 => 29,  98 => 26,  95 => 25,  91 => 24,  85 => 21,  77 => 15,  69 => 13,  63 => 10,  59 => 9,  54 => 8,  52 => 7,  47 => 6,  44 => 5,  39 => 1,  37 => 3,  35 => 2,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layout/site.twig\" %}
{% set pageTitle = release.title %}
{% set customFooter = true %}

{% block content %}
    <div class=\"background {{release.background_type == 'image' ? release.back_img_link: ''}}\">
    {% if release.background_type == 'video' %}
        <video id=\"gallery_video\" autoplay loop muted playsinline class=\"{{release.theme_color}}-border invisible slowload\">
            <source src=\"{{config('links.s3_img_link') ~ 'releases/gallery/' ~ release.back_img_link}}.webm\" type=\"video/webm\">
            <source src=\"{{config('links.s3_img_link') ~ 'releases/gallery/' ~ release.back_img_link}}.mp4\" type=\"video/mp4\">
        </video>
    {% else %}
    <div class=\"back_img\"><img src=\"{{config('links.s3_img_link')}}releases/backgrounds/{{release.back_img_link}}\"></div>
    {% endif %}
    </div>
\t<div class=\"mobile_content\">
\t\t<div id=\"main-content\" class=\"main-content \">
\t\t\t<div class=\"scroll-view\">
\t\t\t\t<div class=\"albumContainer\">
\t\t\t\t\t<div class=\"albumArtContainer\">
\t\t\t\t\t\t<img id=\"albumartImg\" data-js=\"lowresimageload\" class=\"albumArtImg\" src=\"{{config('links.s3_img_link') ~ 'releases/album_arts/' ~ release.img_link}}\">
\t\t\t\t\t</div>
\t\t\t\t\t<div id=\"previewsDiv\" class=\"previews\">
\t\t\t\t\t\t{% for song in songs %}
\t\t\t\t\t\t\t<div class=\"songPreviewDiv\">
\t\t\t\t\t\t\t\t<div class=\"songPreviewButtonsDiv {{release.theme_color}}-border\" data-module=\"audio\">
\t\t\t\t\t\t\t\t\t<div style=\"display: none;\">
\t\t\t\t\t\t\t\t\t\t<audio controls=\"\" class=\"songPreviewAudio\">
\t\t\t\t\t\t\t\t\t\t\t<source src=\"{{config('links.s3_audio_link') ~ 'audio/previews/' ~ song.audio_link}}\" type=\"audio/mpeg\">
\t\t\t\t\t\t\t\t\t\t\tYour browser does not support the audio element.
\t\t\t\t\t\t\t\t\t\t</audio>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<svg class=\"playingCircle hidden {{release.theme_color}}-stroke\" viewbox=\"0 0 100 100\">
\t\t\t\t\t\t\t\t\t\t<circle cx=\"50\" cy=\"50\" r=\"40\"></circle>
\t\t\t\t\t\t\t\t\t</svg>
\t\t\t\t\t\t\t\t\t<div class=\"songPreviewButton songPreviewPlayButton {{release.theme_color}}-fill\">
\t\t\t\t\t\t\t\t\t\t<svg x=\"0px\" y=\"0px\" viewbox=\"0 0 17.804 17.804\" style=\"enable-background:new 0 0 17.804 17.804;\" xml:space=\"preserve\">
\t\t\t\t\t\t\t\t\t\t\t<path d=\"M2.067,0.043C2.21-0.028,2.372-0.008,2.493,0.085l13.312,8.503c0.094,0.078,0.154,0.191,0.154,0.313    c0,0.12-0.061,0.237-0.154,0.314L2.492,17.717c-0.07,0.057-0.162,0.087-0.25,0.087l-0.176-0.04    c-0.136-0.065-0.222-0.207-0.222-0.361V0.402C1.844,0.25,1.93,0.107,2.067,0.043z\"></path>
\t\t\t\t\t\t\t\t\t\t</svg>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"songPreviewButton songPreviewStopButton {{release.theme_color}}-fill hidden\">
\t\t\t\t\t\t\t\t\t\t<svg x=\"0px\" y=\"0px\" viewbox=\"0 0 10.334 10.334\" style=\"enable-background:new 0 0 10.334 10.334;\" xml:space=\"preserve\">
\t\t\t\t\t\t\t\t\t\t\t<path d=\"M10.333,9.816c0,0.285-0.231,0.518-0.517,0.518H0.517C0.233,10.334,0,10.102,0,9.816V0.517   C0,0.232,0.231,0,0.517,0h9.299c0.285,0,0.517,0.231,0.517,0.517V9.816z\"></path>
\t\t\t\t\t\t\t\t\t\t</svg>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"songPreviewTextDiv {{release.theme_color}}-text\">
\t\t\t\t\t\t\t\t\t<div class=\"songPreviewTrackNumber\">{{song.track_number}}.</div>
\t\t\t\t\t\t\t\t\t{% if song.title|length > 15 %}
\t\t\t\t\t\t\t\t\t\t<div class=\"songPreviewTitle\" style=\"font-size:75%;\">{{song.title|raw}}</div>
\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t<div class=\"songPreviewTitle\" style=\"\">{{song.title}}</div>
\t\t\t\t\t\t\t\t\t{% endif %}

\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t</div>
\t\t\t\t\t{% if release.youtube_link %}
\t\t\t\t\t\t<div id=\"youtube_cont_id\">
\t\t\t\t\t\t\t<iframe width=\"95%\" height=\"100%\" src=\"{{release.youtube_link}}\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen=\"\"></iframe>
\t\t\t\t\t\t</div>
\t\t\t\t\t{% endif %}

\t\t\t\t\t{% if other_releases %}
\t\t\t\t\t\t<hr style=\"margin-top:0px\">
\t\t\t\t\t\t<div id=\"other_releases_div\">
\t\t\t\t\t\t\t<div id=\"previoustext\" class=\"listenText\" style=\"justify-self: flex-start;margin-bottom: 20px;\">Other Releases</div>
\t\t\t\t\t\t\t<div class=\"x-scroll-container\">
\t\t\t\t\t\t\t\t<div id=\"other_releases_grid\">
\t\t\t\t\t\t\t\t\t{% for item in other_releases %}
\t\t\t\t\t\t\t\t\t\t<div class=\"other_release_grid_item\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{route('music::release',[item.id])}}\"><img src=\"{{config('links.s3_img_link') ~ 'releases/album_arts/' ~ item.img_link}}\"></a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<hr style=\"margin-top:0px; margin-bottom:20px;\">
\t\t\t\t\t{% endif %}
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div id=\"storesDiv\" class=\"storesDiv {{release.theme_color}}-dark-back\">
\t\t\t\t<div id=\"listentext\" class=\"listenText {{release.theme_color}}-text\" style=\"justify-self: flex-start;margin-bottom: 20px;\">Listen on</div>
\t\t\t\t<div class=\"x-scroll-container\">
\t\t\t\t\t<div id=\"storeLinksDiv\" class=\"storesList\">
\t\t\t\t\t\t<div class=\"storeLink\">
\t\t\t\t\t\t\t<a class=\"storeImage\" href=\"{{release.spotify_link}}\" target=\"_blank\">
\t\t\t\t\t\t\t\t<img style=\"width:100%\" src=\"{{config('links.s3_img_link') ~ 'releases/store_logos/spotify.png'}}\">
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<div class=\"storeText\">Spotify</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"storeLink\">
\t\t\t\t\t\t\t<a class=\"storeImage\" href=\"{{release.itunes_link}}\" target=\"_blank\">
\t\t\t\t\t\t\t\t<img style=\"width:100%\" src=\"{{config('links.s3_img_link') ~ 'releases/store_logos/appleMusic.png'}}\">
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<div class=\"storeText\">Apple Music</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"storeLink\">
\t\t\t\t\t\t\t<a class=\"storeImage\" href=\"{{release.youtube_music_link}}\" target=\"_blank\">
\t\t\t\t\t\t\t\t<img style=\"width:100%\" src=\"{{config('links.s3_img_link') ~ 'releases/store_logos/youtubeMusic.png'}}\">
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<div class=\"storeText\">Youtube</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"storeLink\">
\t\t\t\t\t\t\t<a class=\"storeImage\" href=\"{{release.amazon_link}}\" target=\"_blank\">
\t\t\t\t\t\t\t\t<img style=\"width:100%\" src=\"{{config('links.s3_img_link') ~ 'releases/store_logos/amazon.png'}}\">
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<div class=\"storeText\">Amazon Music</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"storeLink\">
\t\t\t\t\t\t\t<a class=\"storeImage\" href=\"{{release.distrokid_link}}\" target=\"_blank\">
\t\t\t\t\t\t\t\t<svg style=\"width:100%\" class=\"{{release.theme_color}}-fill\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" id=\"Layer_1\" x=\"0px\" y=\"0px\" viewbox=\"0 0 330 330\" xml:space=\"preserve\">
\t\t\t\t\t\t\t\t\t<path id=\"XMLID_22_\" d=\"M165,0C74.019,0,0,74.019,0,165s74.019,165,165,165s165-74.019,165-165S255.981,0,165,0z M85,190  c-13.785,0-25-11.215-25-25s11.215-25,25-25s25,11.215,25,25S98.785,190,85,190z M165,190c-13.785,0-25-11.215-25-25  s11.215-25,25-25s25,11.215,25,25S178.785,190,165,190z M245,190c-13.785,0-25-11.215-25-25s11.215-25,25-25  c13.785,0,25,11.215,25,25S258.785,190,245,190z\"></path>
\t\t\t\t\t\t\t\t</svg>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<div class=\"storeText\">More</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div style=\"width:5px;margin-right:10px\">&nbsp;</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t    </div>
    </div>
    <div class=\"desktop_content\" data-module=\"slowload\">
        <div id=\"main-content\" class=\"main-content-release-desktop {{release.back_img_link}} scroll-x-view\">
            <div class=\"left-side-release\">
                <div class=\"albumArtContainer\">
                    <img id=\"albumartImg\" data-js=\"lowresimageload\" class=\"albumArtImg\" src=\"{{config('links.s3_img_link') ~ 'releases/album_arts/' ~ release.img_link}}\">
                    <div class=\"storeText\">{{release.title}}</div>
                    <div class=\"storeText {{release.theme_color}}-text\" style=\"font-size:100%;margin:10px;\">{{release.subtitle}}</div>
                </div>
                {% if release.description %}
                <div class=\"left-side-description\">
                    <p class=\"left-side-description-title {{release.theme_color}}-text\">About The Album:</p>
                    <p>{{release.description|raw}}</p>
                    <p>© {{release.release_date|slice(0,4)}} Isaac McDougal, IEMG LLC</p>
                </div>
                {% endif %}
            </div>
            <div class=\"middle-side-release\">
                <div class=\"scroll-y-view scroll\">
                    <div id=\"previewsDiv\" class=\"previews\">
                        {% for song in songs %}
                            <div class=\"songPreviewDiv\">
                                <div class=\"songPreviewButtonsDiv {{release.theme_color}}-border\" data-module=\"audio\">
                                    <div style=\"display: none;\">
                                        <audio controls=\"\" class=\"songPreviewAudio\">
                                            <source src=\"{{config('links.s3_audio_link') ~'audio/previews/' ~ song.audio_link}}\" type=\"audio/mpeg\">
                                            Your browser does not support the audio element.
                                        </audio>
                                    </div>
                                    <svg class=\"playingCircle hidden {{release.theme_color}}-stroke\" viewbox=\"0 0 100 100\">
                                        <circle cx=\"50\" cy=\"50\" r=\"40\"></circle>
                                    </svg>
                                    <div class=\"songPreviewButton songPreviewPlayButton {{release.theme_color}}-fill\">
                                        <svg x=\"0px\" y=\"0px\" viewbox=\"0 0 17.804 17.804\" style=\"enable-background:new 0 0 17.804 17.804;\" xml:space=\"preserve\">
                                            <path d=\"M2.067,0.043C2.21-0.028,2.372-0.008,2.493,0.085l13.312,8.503c0.094,0.078,0.154,0.191,0.154,0.313    c0,0.12-0.061,0.237-0.154,0.314L2.492,17.717c-0.07,0.057-0.162,0.087-0.25,0.087l-0.176-0.04    c-0.136-0.065-0.222-0.207-0.222-0.361V0.402C1.844,0.25,1.93,0.107,2.067,0.043z\"></path>
                                        </svg>
                                    </div>
                                    <div class=\"songPreviewButton songPreviewStopButton {{release.theme_color}}-fill hidden\">
                                        <svg x=\"0px\" y=\"0px\" viewbox=\"0 0 10.334 10.334\" style=\"enable-background:new 0 0 10.334 10.334;\" xml:space=\"preserve\">
                                            <path d=\"M10.333,9.816c0,0.285-0.231,0.518-0.517,0.518H0.517C0.233,10.334,0,10.102,0,9.816V0.517   C0,0.232,0.231,0,0.517,0h9.299c0.285,0,0.517,0.231,0.517,0.517V9.816z\"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class=\"songPreviewTextDiv {{release.theme_color}}-text\">
                                    <div class=\"songPreviewTrackNumber\">{{song.track_number}}.</div>
                                    {% if song.title|length > 15 %}
                                        <div class=\"songPreviewTitle\" style=\"font-size:75%;\">{{song.title|raw}}</div>
                                    {% else %}
                                        <div class=\"songPreviewTitle\" style=\"\">{{song.title}}</div>
                                    {% endif %}

                                </div>
                            </div>
                        {% endfor %}
                    </div>
                </div>
                <div id=\"storesDiv\" class=\"storesDiv\">
                        <div id=\"listentext\" class=\"listenText {{release.theme_color}}-text\" style=\"justify-self: flex-start;margin-bottom: 20px;\">Listen on</div>
                        <div class=\"scroll-y-view\" style=\"width:90%;\">
                            <div id=\"storeLinksDiv\" class=\"storesList\">
                                <div class=\"storeLink\">
                                    <a class=\"storeImage\" href=\"{{release.spotify_link}}\" target=\"_blank\">
                                        <img style=\"width:100%\" src=\"{{config('links.s3_img_link') ~ 'releases/store_logos/spotify.png'}}\">
                                    </a>
                                     <a class=\"storeText {{release.theme_color}}-text\" href=\"{{release.spotify_link}}\" target=\"_blank\">Spotify</a>
                                </div>

                                <div class=\"storeLink\">
                                    <a class=\"storeImage\" href=\"{{release.itunes_link}}\" target=\"_blank\">
                                        <img style=\"width:100%\" src=\"{{config('links.s3_img_link') ~ 'releases/store_logos/appleMusic.png'}}\">
                                    </a>
                                    <a class=\"storeText {{release.theme_color}}-text\" href=\"{{release.itunes_link}}\" target=\"_blank\">Apple Music</a>
                                </div>

                                <div class=\"storeLink\">
                                    <a class=\"storeImage\" href=\"{{release.youtube_music_link}}\" target=\"_blank\">
                                        <img style=\"width:100%\" src=\"{{config('links.s3_img_link') ~ 'releases/store_logos/youtubeMusic.png'}}\">
                                    </a>
                                    <a class=\"storeText {{release.theme_color}}-text\" href=\"{{release.youtube_music_link}}\" target=\"_blank\">Youtube Music</a>
                                </div>

                                <div class=\"storeLink\">
                                    <a class=\"storeImage\" href=\"{{release.amazon_link}}\" target=\"_blank\">
                                        <img style=\"width:100%\" src=\"{{config('links.s3_img_link') ~ 'releases/store_logos/amazon.png'}}\">
                                    </a>
                                    <a class=\"storeText {{release.theme_color}}-text\" href=\"{{release.amazon_link}}\" target=\"_blank\">Amazon</a>
                                </div>

                                <div class=\"storeLink\">
                                    <a class=\"storeImage\" href=\"{{release.distrokid_link}}\" target=\"_blank\">
                                        <svg style=\"width:100%\" class=\"{{release.theme_color}}-fill\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" id=\"Layer_1\" x=\"0px\" y=\"0px\" viewbox=\"0 0 330 330\" xml:space=\"preserve\">
                                            <path id=\"XMLID_22_\" d=\"M165,0C74.019,0,0,74.019,0,165s74.019,165,165,165s165-74.019,165-165S255.981,0,165,0z M85,190  c-13.785,0-25-11.215-25-25s11.215-25,25-25s25,11.215,25,25S98.785,190,85,190z M165,190c-13.785,0-25-11.215-25-25  s11.215-25,25-25s25,11.215,25,25S178.785,190,165,190z M245,190c-13.785,0-25-11.215-25-25s11.215-25,25-25  c13.785,0,25,11.215,25,25S258.785,190,245,190z\"></path>
                                        </svg>
                                    </a>
                                    <a class=\"storeText {{release.theme_color}}-text\" href=\"{{release.distrokid_link}}\" target=\"_blank\">More</a>
                                </div>
                                <div style=\"width:5px;margin-right:10px\">&nbsp;</div>
                            </div>
                    </div>
                </div>
            </div>
            <div class=\"right-side-release\">
                {% if release.youtube_link %}
                    <div id=\"youtube_cont_id\">
                        <iframe width=\"100%\" height=\"100%\" src=\"{{release.youtube_link}}\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen=\"\"></iframe>
                    </div>
                {% else %}
                    <div id=\"youtube_cont_id\">
                        <video id=\"gallery_video\" autoplay loop muted playsinline class=\"{{release.theme_color}}-border invisible slowload\"  width=\"100%\" height=\"100%\">
                            <source src=\"{{config('links.s3_img_link') ~ 'releases/gallery/' ~ release.gallery_img_link}}.webm\" type=\"video/webm\">
                            <source src=\"{{config('links.s3_img_link') ~ 'releases/gallery/' ~ release.gallery_img_link}}.mp4\" type=\"video/mp4\">
                        </video>
                    </div>
                {% endif %}
                {% if other_releases %}
                    <div id=\"other_releases_div\">
                        <div id=\"previoustext\" class=\"listenText\" style=\"justify-self: flex-start;margin-bottom: 20px;\">Other Releases</div>
                        <div class=\"x-scroll-container scroll\">
                            <div id=\"other_releases_grid\">
                                {% for item in other_releases %}
                                    <div class=\"other_release_grid_item\">
                                        <a href=\"{{route('music::release',[item.id])}}\"><img src=\"{{config('links.s3_img_link') ~ 'releases/album_arts/' ~ item.img_link}}\" class=\"invisible visible\" onload=\"this.classList.remove('invisible')\"></a>
                                    </div>
                                {% endfor %}
                            </div>
                        </div>
                    </div>
                {% endif %}
        </div>
    </div>
\t{% endblock %}
", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/music/release.twig", "");
    }
}
