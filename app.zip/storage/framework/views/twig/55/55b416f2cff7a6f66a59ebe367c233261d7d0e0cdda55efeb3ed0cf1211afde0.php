<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\Users\isaac\Documents\Projects\ipm\resources\views/admin/login.twig */
class __TwigTemplate_4257921fc7543292a6df1d3bcd0730091ba52df837511c4435041cc8e646cca5 extends TwigBridge\Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "_layout/site.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["pageTitle"] = "Admin Login";
        // line 3
        $this->parent = $this->loadTemplate("_layout/site.twig", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/admin/login.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        // line 6
        echo "\t<div class=\"header_content slowload\" data-module=\"slowload\">
    <div class=\"back_img\"><img src=\"";
        // line 7
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]), "html", null, true);
        echo "releases/backgrounds/sd-back.png\"></div>
    <div class=\"admin_div\">
\t\t<form class=\"admin_form\" method=\"POST\" action=\"";
        // line 9
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["admin::loginsubmit"]);
        echo "\">
        ";
        // line 10
        echo csrf_field();
        echo "
\t\t\t<div class=\"form_input_with_label flex-row\">
                <p>Admin Username:</p>
                <input name=\"username\">
            </div>
\t\t\t<div class=\"form_input_with_label flex-row\">
                <p>Admin Password:</p>
                <input name=\"password\" type=\"password\">
            </div>
\t\t\t<button type=\"submit\" class=\"white_border_button\">Login</button>
\t\t</form>
        </div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/admin/login.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 10,  53 => 9,  48 => 7,  45 => 6,  42 => 5,  37 => 3,  35 => 1,  29 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% set pageTitle = \"Admin Login\" %}

{% extends \"_layout/site.twig\" %}

{% block content %}
\t<div class=\"header_content slowload\" data-module=\"slowload\">
    <div class=\"back_img\"><img src=\"{{config('links.s3_img_link')}}releases/backgrounds/sd-back.png\"></div>
    <div class=\"admin_div\">
\t\t<form class=\"admin_form\" method=\"POST\" action=\"{{route('admin::loginsubmit')}}\">
        {{ csrf_field() }}
\t\t\t<div class=\"form_input_with_label flex-row\">
                <p>Admin Username:</p>
                <input name=\"username\">
            </div>
\t\t\t<div class=\"form_input_with_label flex-row\">
                <p>Admin Password:</p>
                <input name=\"password\" type=\"password\">
            </div>
\t\t\t<button type=\"submit\" class=\"white_border_button\">Login</button>
\t\t</form>
        </div>
\t</div>
{% endblock %}
", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/admin/login.twig", "");
    }
}
