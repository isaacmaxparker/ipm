<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\Users\isaac\Documents\Projects\ipm\resources\views/admin/dashboard.twig */
class __TwigTemplate_feb75004d8d7b93631c3204bab0c2815caa6307501c32fdbfdb45a171a7c3b68 extends TwigBridge\Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "_layout/adminsite.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["pageTitle"] = "Admin Dashboard";
        // line 3
        $this->parent = $this->loadTemplate("_layout/adminsite.twig", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/admin/dashboard.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        // line 6
        echo "\t<div class=\"header_content slowload\" data-module=\"slowload\">
\t\t<div class=\"back_img\"><img src=\"";
        // line 7
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]), "html", null, true);
        echo "releases/backgrounds/cn-back.png\"></div>
\t\t<div class=\"admin_div\">
\t\t\t<div class=\"flex-column y-scroll-div\">
\t\t\t\t<a href=\"";
        // line 10
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["admin::releases"]);
        echo "\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tManage Releases
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"";
        // line 15
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["admin::songs"]);
        echo "\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tManage Songs
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"";
        // line 20
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["admin::products"]);
        echo "\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tManage Products
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"";
        // line 25
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["admin::orders"]);
        echo "\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tManage Orders
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"";
        // line 30
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["admin::customers"]);
        echo "\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tManage Customers
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"";
        // line 35
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["admin::promos"]);
        echo "\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tManage Promos
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"";
        // line 40
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["admin::tiles"]);
        echo "\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tManage Home Tiles
\t\t\t\t\t</div>
\t\t\t\t</a>
                <a href=\"";
        // line 45
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["admin::logout"]);
        echo "\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tLog Out
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t</div>
\t\t</div>
\t";
    }

    public function getTemplateName()
    {
        return "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/admin/dashboard.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 45,  102 => 40,  94 => 35,  86 => 30,  78 => 25,  70 => 20,  62 => 15,  54 => 10,  48 => 7,  45 => 6,  42 => 5,  37 => 3,  35 => 1,  29 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% set pageTitle = \"Admin Dashboard\" %}

{% extends \"_layout/adminsite.twig\" %}

{% block content %}
\t<div class=\"header_content slowload\" data-module=\"slowload\">
\t\t<div class=\"back_img\"><img src=\"{{config('links.s3_img_link')}}releases/backgrounds/cn-back.png\"></div>
\t\t<div class=\"admin_div\">
\t\t\t<div class=\"flex-column y-scroll-div\">
\t\t\t\t<a href=\"{{route('admin::releases')}}\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tManage Releases
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"{{route('admin::songs')}}\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tManage Songs
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"{{route('admin::products')}}\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tManage Products
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"{{route('admin::orders')}}\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tManage Orders
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"{{route('admin::customers')}}\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tManage Customers
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"{{route('admin::promos')}}\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tManage Promos
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t\t<a href=\"{{route('admin::tiles')}}\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tManage Home Tiles
\t\t\t\t\t</div>
\t\t\t\t</a>
                <a href=\"{{route('admin::logout')}}\" class=\"dashboard_link\">
\t\t\t\t\t<div class=\"dashboard_item\">
\t\t\t\t\t\tLog Out
\t\t\t\t\t</div>
\t\t\t\t</a>
\t\t\t</div>
\t\t</div>
\t{% endblock %}
", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/admin/dashboard.twig", "");
    }
}
