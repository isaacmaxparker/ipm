<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\Users\isaac\Documents\Projects\ipm\resources\views/store/checkout.twig */
class __TwigTemplate_f2b672fb89887d4e645279f0a4eeff92e10320fd282f93d322db266fa095a9dd extends TwigBridge\Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 6
        return "_layout/site.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["pageTitle"] = "Checkout";
        // line 2
        $context["pageBackLink"] = true;
        // line 3
        $context["backLinkURL"] = "route('store::index')";
        // line 4
        $context["customFooter"] = false;
        // line 6
        $this->parent = $this->loadTemplate("_layout/site.twig", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/store/checkout.twig", 6);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 8
    public function block_content($context, array $blocks = [])
    {
        // line 9
        echo "<div class=\"background sd-rainbow-back\">
    <div class=\"mobile_content back-white\">
        <div class=\"y-scroll-div full_screen_scroll_footer\">
            <div class=\"flex-column checkout_div\">
                <div class=\"checkout-cart-div flex-column\">
                <div class=\"top_border\"></div>
                ";
        // line 15
        if ((twig_length_filter($this->env, ($context["cart_items"] ?? null)) > 0)) {
            // line 16
            echo "                <div class=\"checkout-cart-items-div\">
                    ";
            // line 17
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["cart_items"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 18
                echo "                        <div data-viewmode=\"-mobile\" data-module=\"deletecart\" data-id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "cart_item_id", []), "html", null, true);
                echo "\" data-quant=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "quantity", []), "html", null, true);
                echo "\" id=\"cart_item-";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "cart_item_id", []), "html", null, true);
                echo "-mobile\" class=\"checkout-cart-item flex-row\">
                            <div class=\"checkout-cart-item-buttons\">
                                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"14\" height=\"14\" viewBox=\"0 0 24 24\"><path d=\"M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm6 16.538l-4.592-4.548 4.546-4.587-1.416-1.403-4.545 4.589-4.588-4.543-1.405 1.405 4.593 4.552-4.547 4.592 1.405 1.405 4.555-4.596 4.591 4.55 1.403-1.416z\"/></svg>
                            </div>
                            <img src=\"";
                // line 22
                echo call_user_func_array($this->env->getFunction('asset')->getCallable(), [("img/store/" . $this->getAttribute($context["item"], "img_link", []))]);
                echo "\">
                            <div class=\"flex-column checkout-cart-name-div\">
                                <p>";
                // line 24
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", []), "html", null, true);
                echo "<br><span style=\"opacity:.7;font-size:80%\"><i>+ FREE Signed Poster</i></span></p>
                                <p>";
                // line 25
                ((($this->getAttribute($context["item"], "quantity", []) > 1)) ? (print (twig_escape_filter($this->env, (($this->getAttribute($context["item"], "quantity", []) . " x \$") . $this->getAttribute($context["item"], "price", [])), "html", null, true))) : (print ("")));
                echo "</p>
                            </div>
                            <div class=\"checkout-cart-item-total-div flex-column\">
                                <p>\$";
                // line 28
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["item"], "total", []), 2, ".", ","), "html", null, true);
                echo "</p>
                                ";
                // line 29
                if ($this->getAttribute($context["item"], "discount", [])) {
                    echo "<p>- \$";
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["item"], "discount", []), 2, ".", ","), "html", null, true);
                    echo "</p>";
                }
                // line 30
                echo "                            </div>
                        </div>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 33
            echo "                </div>
                <hr class=\"dark-grey-line\" style=\"margin-top:auto\">
                    <div class=\"checkout-cart-totals-div flex-column\">
                        <p><b>Cart Total: </b><span class=\"cart_total-mobile\">\$";
            // line 36
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["cart_total"] ?? null), 2, ".", ","), "html", null, true);
            echo "</span></p>
                    </div>
                    <div id=\"shipping-mobile\" class=\"checkout-shipping-totals-div flex-column\">
                        <p><b>Shipping: </b><span class=\"shipping_total-mobile\">\$";
            // line 39
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["shipping"] ?? null), 2, ".", ","), "html", null, true);
            echo "</span></p>
                    </div>
                    <div class=\"checkout-full-total-div flex-column\">
                        <p><b>Order Total: </b><span class=\"order_total-mobile\">\$";
            // line 42
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (($context["cart_total"] ?? null) + ($context["shipping"] ?? null)), 2, ".", ","), "html", null, true);
            echo "</span></p>
                    </div>
                </div>
                <hr class=\"dark-grey-line\">
                <div data-module=\"promocode\" data-viewmode=\"-mobile\">
                    <div id=\"checkout-promos-applied-mobile\" class=\"";
            // line 47
            echo ((($context["promo"] ?? null)) ? ("") : ("hidden"));
            echo " checkout-promos-div flex-row\">
                        <div class=\"checkout-cart-item-buttons\">
                            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"13\" height=\"13\" viewBox=\"0 0 24 24\"><path d=\"M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm6 16.538l-4.592-4.548 4.546-4.587-1.416-1.403-4.545 4.589-4.588-4.543-1.405 1.405 4.593 4.552-4.547 4.592 1.405 1.405 4.555-4.596 4.591 4.55 1.403-1.416z\"/></svg>
                        </div>
                        <p id=\"checkout-promos-applied-message-mobile\" class=\"checkout-promos-message\">Code: ";
            // line 51
            echo twig_escape_filter($this->env, ($context["promo"] ?? null), "html", null, true);
            echo " has been applied</p>
                    </div>
                    <div id=\"checkout-promos-div-mobile\" class=\"";
            // line 53
            echo ((($context["promo"] ?? null)) ? ("hidden") : (""));
            echo " checkout-promos-div flex-row\">
                        <input id=\"checkout-cart-promo\" type=\"text\" placeholder=\"Enter Promo Code\"><div data-viewmode=\"-mobile\" class=\"product-button flex-row\" data-inputid=\"checkout-cart-promo\"><p>Add Promo</p></div>
                    </div>
                    <div class=\"checkout-promos-message-div-mobile flex-row hidden\">
                        <p id=\"checkout-promos-message-mobile\" class=\"checkout-promos-message\"></p>
                    </div>
                </div>
                ";
            // line 63
            echo "                <hr class=\"dark-grey-line\" style=\"margin-bottom:auto\">
                <div class=\"checkout-billing-div flex-column\" data-module=\"paypal\">
                    <div id=\"paypal-button-container\"></div>
                </div>
                ";
        } else {
            // line 68
            echo "                    <p>No items in cart</p>
                    <a href=\"";
            // line 69
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["store::catalog"]);
            echo "\">Browse Shop</a>
                 ";
        }
        // line 71
        echo "                </div>
            </div>
        </div>
    </div>
    <div class=\"desktop_content checkout_desktop\">
    <img class=\"back_img\" src=\"";
        // line 76
        echo call_user_func_array($this->env->getFunction('asset')->getCallable(), ["img/backgrounds/sd-back-rainbow.png"]);
        echo "\">
    <div class=\"desktop-scroll\">
        <div class=\"y-scroll-div \">
            <div class=\"flex-column checkout_div\">
                <div class=\"checkout-cart-div flex-row\">
                ";
        // line 81
        if ((twig_length_filter($this->env, ($context["cart_items"] ?? null)) > 0)) {
            // line 82
            echo "                    <div class=\"flex-column desktop-cart-div\">
                        <div class=\"top_border\"></div>
                        <div class=\"checkout-cart-items-div y-scroll-div\">
                            ";
            // line 85
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["cart_items"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 86
                echo "                                <div data-viewmode=\"-desktop\" data-module=\"deletecart\" data-quant=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "quantity", []), "html", null, true);
                echo "\" data-id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "cart_item_id", []), "html", null, true);
                echo "\" id=\"cart_item-";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "cart_item_id", []), "html", null, true);
                echo "-desktop\" class=\"checkout-cart-item flex-row\">
                                    <div class=\"checkout-cart-item-buttons\">
                                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"14\" height=\"14\" viewBox=\"0 0 24 24\"><path d=\"M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm6 16.538l-4.592-4.548 4.546-4.587-1.416-1.403-4.545 4.589-4.588-4.543-1.405 1.405 4.593 4.552-4.547 4.592 1.405 1.405 4.555-4.596 4.591 4.55 1.403-1.416z\"/></svg>
                                    </div>
                                    <img src=\"";
                // line 90
                echo call_user_func_array($this->env->getFunction('asset')->getCallable(), [("img/store/" . $this->getAttribute($context["item"], "img_link", []))]);
                echo "\">
                                    <div class=\"flex-column checkout-cart-name-div\">
                                        <p>";
                // line 92
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", []), "html", null, true);
                echo "<br><span style=\"opacity:.7;font-size:80%\"><i>+ FREE Signed Poster</i></span></p>
                                        <p>";
                // line 93
                ((($this->getAttribute($context["item"], "quantity", []) > 1)) ? (print (twig_escape_filter($this->env, (($this->getAttribute($context["item"], "quantity", []) . " x \$") . $this->getAttribute($context["item"], "price", [])), "html", null, true))) : (print ("")));
                echo "</p>
                                    </div>
                                    <div class=\"checkout-cart-item-total-div flex-column\">
                                        <p>\$";
                // line 96
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["item"], "total", []), 2, ".", ","), "html", null, true);
                echo "</p>
                                        ";
                // line 97
                if ($this->getAttribute($context["item"], "discount", [])) {
                    echo "<p>- \$";
                    echo twig_escape_filter($this->env, twig_number_format_filter($this->env, $this->getAttribute($context["item"], "discount", []), 2, ".", ","), "html", null, true);
                    echo "</p>";
                }
                // line 98
                echo "                                    </div>
                                </div>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 101
            echo "                        </div>
                        <hr class=\"dark-grey-line\" style=\"margin-top:auto\">
                            <div class=\"checkout-cart-totals-div flex-column\">
                                <p><b>Cart Total: </b><span class=\"cart_total-desktop\">\$";
            // line 104
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["cart_total"] ?? null), 2, ".", ","), "html", null, true);
            echo "</span></p>
                            </div>
                            <div id=\"shipping-desktop\" class=\"checkout-shipping-totals-div flex-column\">
                                <p><b>Shipping: </b><span class=\"shipping_total-desktop\">\$";
            // line 107
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, ($context["shipping"] ?? null), 2, ".", ","), "html", null, true);
            echo "</span></p>
                            </div>
                            <div class=\"checkout-full-total-div flex-column\">
                                <p><b>Order Total: </b><span class=\"order_total-desktop\">\$";
            // line 110
            echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (($context["cart_total"] ?? null) + ($context["shipping"] ?? null)), 2, ".", ","), "html", null, true);
            echo "</span></p>
                            </div>
                        </div>
                    </div>
                    <div class=\"flex-column\" style=\"margin-bottom:auto;\">
                        <hr class=\"dark-grey-line\">
                        <div data-module=\"promocode\" data-viewmode=\"-desktop\" class=\"promo_section\">
                            <div id=\"checkout-promos-applied-desktop\" class=\"";
            // line 117
            echo ((($context["promo"] ?? null)) ? ("") : ("hidden"));
            echo " checkout-promos-div flex-row\">
                                <div class=\"checkout-cart-item-buttons\">
                                    <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"13\" height=\"13\" viewBox=\"0 0 24 24\"><path d=\"M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm6 16.538l-4.592-4.548 4.546-4.587-1.416-1.403-4.545 4.589-4.588-4.543-1.405 1.405 4.593 4.552-4.547 4.592 1.405 1.405 4.555-4.596 4.591 4.55 1.403-1.416z\"/></svg>
                                </div>
                                <p id=\"checkout-promos-applied-message-desktop\" class=\"checkout-promos-message\">Code: ";
            // line 121
            echo twig_escape_filter($this->env, ($context["promo"] ?? null), "html", null, true);
            echo " has been applied</p>
                            </div>
                            <div id=\"checkout-promos-div-desktop\" class=\"";
            // line 123
            echo ((($context["promo"] ?? null)) ? ("hidden") : (""));
            echo " checkout-promos-div flex-row\">
                                <input id=\"checkout-cart-promo-desktop\" type=\"text\" placeholder=\"Enter Promo Code\"><div data-viewmode=\"-desktop\" class=\"product-button flex-row\" data-inputid=\"checkout-cart-promo-desktop\"><p>Add Promo</p></div>
                            </div>
                            <div class=\"checkout-promos-message-div-desktop flex-row hidden\">
                                <p id=\"checkout-promos-message-desktop\" class=\"checkout-promos-message\"></p>
                            </div>
                        </div>
                        <hr class=\"dark-grey-line\">
                    </div>
                    <div class=\"checkout-billing-div flex-column\">
                        <div id=\"paypal-button-container-desktop\"></div>
                    </div>
                </div>
               ";
        } else {
            // line 137
            echo "               <div class=\"flex-column\" style=\"margin-top:20px; margin-bottom:40vh\">
                    <p>No items in cart</p>
                    <a href=\"";
            // line 139
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["store::catalog"]);
            echo "\">Browse Shop</a>
                </div
                ";
        }
        // line 142
        echo "            </div>
        </div>
    </div>
    <input disabled hidden id=\"order-total\"/>
</div>
";
    }

    public function getTemplateName()
    {
        return "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/store/checkout.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  312 => 142,  306 => 139,  302 => 137,  285 => 123,  280 => 121,  273 => 117,  263 => 110,  257 => 107,  251 => 104,  246 => 101,  238 => 98,  232 => 97,  228 => 96,  222 => 93,  218 => 92,  213 => 90,  201 => 86,  197 => 85,  192 => 82,  190 => 81,  182 => 76,  175 => 71,  170 => 69,  167 => 68,  160 => 63,  150 => 53,  145 => 51,  138 => 47,  130 => 42,  124 => 39,  118 => 36,  113 => 33,  105 => 30,  99 => 29,  95 => 28,  89 => 25,  85 => 24,  80 => 22,  68 => 18,  64 => 17,  61 => 16,  59 => 15,  51 => 9,  48 => 8,  43 => 6,  41 => 4,  39 => 3,  37 => 2,  35 => 1,  29 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% set pageTitle = \"Checkout\" %}
{% set pageBackLink = true %}
{% set backLinkURL = \"route('store::index')\"  %}
{% set customFooter = false %}

{% extends \"_layout/site.twig\" %}

{% block content %}
<div class=\"background sd-rainbow-back\">
    <div class=\"mobile_content back-white\">
        <div class=\"y-scroll-div full_screen_scroll_footer\">
            <div class=\"flex-column checkout_div\">
                <div class=\"checkout-cart-div flex-column\">
                <div class=\"top_border\"></div>
                {% if cart_items|length > 0 %}
                <div class=\"checkout-cart-items-div\">
                    {% for item in cart_items %}
                        <div data-viewmode=\"-mobile\" data-module=\"deletecart\" data-id=\"{{item.cart_item_id}}\" data-quant=\"{{item.quantity}}\" id=\"cart_item-{{item.cart_item_id}}-mobile\" class=\"checkout-cart-item flex-row\">
                            <div class=\"checkout-cart-item-buttons\">
                                <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"14\" height=\"14\" viewBox=\"0 0 24 24\"><path d=\"M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm6 16.538l-4.592-4.548 4.546-4.587-1.416-1.403-4.545 4.589-4.588-4.543-1.405 1.405 4.593 4.552-4.547 4.592 1.405 1.405 4.555-4.596 4.591 4.55 1.403-1.416z\"/></svg>
                            </div>
                            <img src=\"{{asset('img/store/' ~ item.img_link)}}\">
                            <div class=\"flex-column checkout-cart-name-div\">
                                <p>{{item.name}}<br><span style=\"opacity:.7;font-size:80%\"><i>+ FREE Signed Poster</i></span></p>
                                <p>{{item.quantity > 1 ? item.quantity ~ ' x \$' ~ item.price : ''}}</p>
                            </div>
                            <div class=\"checkout-cart-item-total-div flex-column\">
                                <p>\${{item.total|number_format(2,'.',',')}}</p>
                                {% if item.discount %}<p>- \${{item.discount|number_format(2,'.',',')}}</p>{% endif %}
                            </div>
                        </div>
                    {% endfor %}
                </div>
                <hr class=\"dark-grey-line\" style=\"margin-top:auto\">
                    <div class=\"checkout-cart-totals-div flex-column\">
                        <p><b>Cart Total: </b><span class=\"cart_total-mobile\">\${{cart_total|number_format(2,'.',',')}}</span></p>
                    </div>
                    <div id=\"shipping-mobile\" class=\"checkout-shipping-totals-div flex-column\">
                        <p><b>Shipping: </b><span class=\"shipping_total-mobile\">\${{shipping|number_format(2,'.',',')}}</span></p>
                    </div>
                    <div class=\"checkout-full-total-div flex-column\">
                        <p><b>Order Total: </b><span class=\"order_total-mobile\">\${{(cart_total + shipping)|number_format(2,'.',',')}}</span></p>
                    </div>
                </div>
                <hr class=\"dark-grey-line\">
                <div data-module=\"promocode\" data-viewmode=\"-mobile\">
                    <div id=\"checkout-promos-applied-mobile\" class=\"{{promo ? '' : 'hidden'}} checkout-promos-div flex-row\">
                        <div class=\"checkout-cart-item-buttons\">
                            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"13\" height=\"13\" viewBox=\"0 0 24 24\"><path d=\"M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm6 16.538l-4.592-4.548 4.546-4.587-1.416-1.403-4.545 4.589-4.588-4.543-1.405 1.405 4.593 4.552-4.547 4.592 1.405 1.405 4.555-4.596 4.591 4.55 1.403-1.416z\"/></svg>
                        </div>
                        <p id=\"checkout-promos-applied-message-mobile\" class=\"checkout-promos-message\">Code: {{promo}} has been applied</p>
                    </div>
                    <div id=\"checkout-promos-div-mobile\" class=\"{{promo ? 'hidden' : ''}} checkout-promos-div flex-row\">
                        <input id=\"checkout-cart-promo\" type=\"text\" placeholder=\"Enter Promo Code\"><div data-viewmode=\"-mobile\" class=\"product-button flex-row\" data-inputid=\"checkout-cart-promo\"><p>Add Promo</p></div>
                    </div>
                    <div class=\"checkout-promos-message-div-mobile flex-row hidden\">
                        <p id=\"checkout-promos-message-mobile\" class=\"checkout-promos-message\"></p>
                    </div>
                </div>
                {# <hr class=\"dark-grey-line\">
                <div class=\"checkout-shipping-div\">
                </div> #}
                <hr class=\"dark-grey-line\" style=\"margin-bottom:auto\">
                <div class=\"checkout-billing-div flex-column\" data-module=\"paypal\">
                    <div id=\"paypal-button-container\"></div>
                </div>
                {% else %}
                    <p>No items in cart</p>
                    <a href=\"{{route('store::catalog')}}\">Browse Shop</a>
                 {% endif %}
                </div>
            </div>
        </div>
    </div>
    <div class=\"desktop_content checkout_desktop\">
    <img class=\"back_img\" src=\"{{asset('img/backgrounds/sd-back-rainbow.png')}}\">
    <div class=\"desktop-scroll\">
        <div class=\"y-scroll-div \">
            <div class=\"flex-column checkout_div\">
                <div class=\"checkout-cart-div flex-row\">
                {% if cart_items|length > 0 %}
                    <div class=\"flex-column desktop-cart-div\">
                        <div class=\"top_border\"></div>
                        <div class=\"checkout-cart-items-div y-scroll-div\">
                            {% for item in cart_items %}
                                <div data-viewmode=\"-desktop\" data-module=\"deletecart\" data-quant=\"{{item.quantity}}\" data-id=\"{{item.cart_item_id}}\" id=\"cart_item-{{item.cart_item_id}}-desktop\" class=\"checkout-cart-item flex-row\">
                                    <div class=\"checkout-cart-item-buttons\">
                                        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"14\" height=\"14\" viewBox=\"0 0 24 24\"><path d=\"M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm6 16.538l-4.592-4.548 4.546-4.587-1.416-1.403-4.545 4.589-4.588-4.543-1.405 1.405 4.593 4.552-4.547 4.592 1.405 1.405 4.555-4.596 4.591 4.55 1.403-1.416z\"/></svg>
                                    </div>
                                    <img src=\"{{asset('img/store/' ~ item.img_link)}}\">
                                    <div class=\"flex-column checkout-cart-name-div\">
                                        <p>{{item.name}}<br><span style=\"opacity:.7;font-size:80%\"><i>+ FREE Signed Poster</i></span></p>
                                        <p>{{item.quantity > 1 ? item.quantity ~ ' x \$' ~ item.price : ''}}</p>
                                    </div>
                                    <div class=\"checkout-cart-item-total-div flex-column\">
                                        <p>\${{item.total|number_format(2,'.',',')}}</p>
                                        {% if item.discount %}<p>- \${{item.discount|number_format(2,'.',',')}}</p>{% endif %}
                                    </div>
                                </div>
                            {% endfor %}
                        </div>
                        <hr class=\"dark-grey-line\" style=\"margin-top:auto\">
                            <div class=\"checkout-cart-totals-div flex-column\">
                                <p><b>Cart Total: </b><span class=\"cart_total-desktop\">\${{cart_total|number_format(2,'.',',')}}</span></p>
                            </div>
                            <div id=\"shipping-desktop\" class=\"checkout-shipping-totals-div flex-column\">
                                <p><b>Shipping: </b><span class=\"shipping_total-desktop\">\${{shipping|number_format(2,'.',',')}}</span></p>
                            </div>
                            <div class=\"checkout-full-total-div flex-column\">
                                <p><b>Order Total: </b><span class=\"order_total-desktop\">\${{(cart_total + shipping)|number_format(2,'.',',')}}</span></p>
                            </div>
                        </div>
                    </div>
                    <div class=\"flex-column\" style=\"margin-bottom:auto;\">
                        <hr class=\"dark-grey-line\">
                        <div data-module=\"promocode\" data-viewmode=\"-desktop\" class=\"promo_section\">
                            <div id=\"checkout-promos-applied-desktop\" class=\"{{promo ? '' : 'hidden'}} checkout-promos-div flex-row\">
                                <div class=\"checkout-cart-item-buttons\">
                                    <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"13\" height=\"13\" viewBox=\"0 0 24 24\"><path d=\"M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm6 16.538l-4.592-4.548 4.546-4.587-1.416-1.403-4.545 4.589-4.588-4.543-1.405 1.405 4.593 4.552-4.547 4.592 1.405 1.405 4.555-4.596 4.591 4.55 1.403-1.416z\"/></svg>
                                </div>
                                <p id=\"checkout-promos-applied-message-desktop\" class=\"checkout-promos-message\">Code: {{promo}} has been applied</p>
                            </div>
                            <div id=\"checkout-promos-div-desktop\" class=\"{{promo ? 'hidden' : ''}} checkout-promos-div flex-row\">
                                <input id=\"checkout-cart-promo-desktop\" type=\"text\" placeholder=\"Enter Promo Code\"><div data-viewmode=\"-desktop\" class=\"product-button flex-row\" data-inputid=\"checkout-cart-promo-desktop\"><p>Add Promo</p></div>
                            </div>
                            <div class=\"checkout-promos-message-div-desktop flex-row hidden\">
                                <p id=\"checkout-promos-message-desktop\" class=\"checkout-promos-message\"></p>
                            </div>
                        </div>
                        <hr class=\"dark-grey-line\">
                    </div>
                    <div class=\"checkout-billing-div flex-column\">
                        <div id=\"paypal-button-container-desktop\"></div>
                    </div>
                </div>
               {% else %}
               <div class=\"flex-column\" style=\"margin-top:20px; margin-bottom:40vh\">
                    <p>No items in cart</p>
                    <a href=\"{{route('store::catalog')}}\">Browse Shop</a>
                </div
                {% endif %}
            </div>
        </div>
    </div>
    <input disabled hidden id=\"order-total\"/>
</div>
{% endblock %}", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/store/checkout.twig", "");
    }
}
