<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\Users\isaac\Documents\Projects\ipm\resources\views/store/order.twig */
class __TwigTemplate_a616c38f6a117fe11e04bdae73b8d35e5c733243e42ac060c80b5a7bd6cab43d extends TwigBridge\Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 5
        return "_layout/site.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["pageTitle"] = "Order";
        // line 2
        $context["pageBackLink"] = false;
        // line 3
        $context["customFooter"] = false;
        // line 5
        $this->parent = $this->loadTemplate("_layout/site.twig", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/store/order.twig", 5);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        // line 8
        echo "\t<div class=\"background sd-white-back\">
\t\t<div class=\"mobile_content white\">
\t\t\t<div class=\"y-scroll-div full_screen_scroll_footer\">
\t\t\t\t<div class=\"flex-column order-columns\">
\t\t\t\t\t<h1>Congratulations!</h1>
\t\t\t\t\t<h2>Your order has been placed!</h2>
\t\t\t\t\t<hr class=\"dark-grey-line\">
\t\t\t\t\t<h3>Thank you
\t\t\t\t\t\t";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "first_name", []), "html", null, true);
        echo "
\t\t\t\t\t\tfor your support!</h3>
\t\t\t\t\t<hr class=\"dark-grey-line\">
\t\t\t\t\t<p>Save this page as confirmation.
\t\t\t\t\t</p>
\t\t\t\t\t<div class=\"order-summary flex-column\">
\t\t\t\t\t\t<p>Order #:
\t\t\t\t\t\t\t";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "order_number", []), "html", null, true);
        echo "</p>
\t\t\t\t\t\t<p>Total: \$";
        // line 24
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "amount", []), "html", null, true);
        echo "</p>
\t\t\t\t\t\t<br>
\t\t\t\t\t\t<p>Items:
\t\t\t\t\t\t</p>
\t\t\t\t\t\t<div class=\"y-scroll-div\" style=\"max-height:30vh\">
\t\t\t\t\t\t\t";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["order_items"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 30
            echo "\t\t\t\t\t\t\t\t<div class=\"flex-row order-item-row\">
\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 31
            echo call_user_func_array($this->env->getFunction('asset')->getCallable(), [("img/store/" . $this->getAttribute($context["item"], "img_link", []))]);
            echo "\">
\t\t\t\t\t\t\t\t\t<p style=\"margin-left:10px;\">";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", []), "html", null, true);
            echo "</p>
\t\t\t\t\t\t\t\t\t<p style=\"margin-left:auto;margin-right:10px;opacity:.6\">";
            // line 33
            ((($this->getAttribute($context["item"], "quantity", []) > 1)) ? (print (twig_escape_filter($this->env, ("x" . $this->getAttribute($context["item"], "quantity", [])), "html", null, true))) : (print ("")));
            echo "</p>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<hr class=\"dark-grey-line\" style=\"margin-top:auto;\">
\t\t\t\t\t<p style=\"width:85vw;font-style:italic;font-weight:normal;margin-top:20px;\">Making music has always been my passion, and now you are part of the reason I get to keep doing it, so thank you!<br>
\t\t\t\t\t\t<br>
\t\t\t\t\t\tEvery order is hand-packed and shipped by me personally so I look forward to sending you yours! Keep on keeping on :)
\t\t\t\t\t\t<br><br><span style=\"font-family:script;float:right;margin-right:10vw;font-size:150%;\">- Isaac</span>
\t\t\t\t\t</p>
\t\t\t\t\t<hr class=\"dark-grey-line\" style=\"margin-top:20px;margin-bottom:25px;\">
                    <div class=\"socials flex-row\">
\t\t\t\t\t\t\t<p style=\"margin-right:10px;font-style:italic;opacity:.3\">Stay Connected with me!</p>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"";
        // line 47
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.instagram"]), "html", null, true);
        echo "\">d</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"";
        // line 48
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.facebook"]), "html", null, true);
        echo "\">c</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"";
        // line 49
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.youtube"]), "html", null, true);
        echo "\">w</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"";
        // line 50
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.spotify"]), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t<svg viewbox=\"0 0 2903 2903\" width=\"26\" height=\"26\">
\t\t\t\t\t\t\t\t\t<style>
\t\t\t\t\t\t\t\t\t\t.st0 {
\t\t\t\t\t\t\t\t\t\t\tfill: rgba(0, 0, 0, 0.809);
\t\t\t\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t\t\t</style><path class=\"st0\" d=\"M1465.5 0C656.1 0 0 656.1 0 1465.5S656.1 2931 1465.5 2931 2931 2274.9 2931 1465.5C2931 656.2 2274.9.1 1465.5 0zm672.1 2113.6c-26.3 43.2-82.6 56.7-125.6 30.4-344.1-210.3-777.3-257.8-1287.4-141.3-49.2 11.3-98.2-19.5-109.4-68.7-11.3-49.2 19.4-98.2 68.7-109.4C1242.1 1697.1 1721 1752 2107.3 1988c43 26.5 56.7 82.6 30.3 125.6zm179.3-398.9c-33.1 53.8-103.5 70.6-157.2 37.6-393.8-242.1-994.4-312.2-1460.3-170.8-60.4 18.3-124.2-15.8-142.6-76.1-18.2-60.4 15.9-124.1 76.2-142.5 532.2-161.5 1193.9-83.3 1646.2 194.7 53.8 33.1 70.8 103.4 37.7 157.1zm15.4-415.6c-472.4-280.5-1251.6-306.3-1702.6-169.5-72.4 22-149-18.9-170.9-91.3-21.9-72.4 18.9-149 91.4-171 517.7-157.1 1378.2-126.8 1922 196 65.1 38.7 86.5 122.8 47.9 187.8-38.5 65.2-122.8 86.7-187.8 48z\"/></svg>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"";
        // line 58
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.itunes"]), "html", null, true);
        echo "\">h</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"";
        // line 59
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.twitter"]), "html", null, true);
        echo "\">o</a>
\t\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"desktop_content back-white\">
\t\t\t<img class=\"back_img\" src=\"";
        // line 65
        echo call_user_func_array($this->env->getFunction('asset')->getCallable(), ["img/backgrounds/sd-back-rainbow.png"]);
        echo "\">
\t\t\t<div class=\"desktop-scroll\">
\t\t\t\t<div class=\"y-scroll-div order_info_div\">
\t\t\t\t\t<div class=\"flex-column order-columns\">
\t\t\t\t\t\t<h1>Congratulations!</h1>
\t\t\t\t\t\t<h2>Your order has been placed!</h2>
\t\t\t\t\t\t<hr class=\"dark-grey-line\">
\t\t\t\t\t\t<h3>Thank you
\t\t\t\t\t\t\t";
        // line 73
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "first_name", []), "html", null, true);
        echo "
\t\t\t\t\t\t\tfor your support!</h3>
\t\t\t\t\t\t<hr class=\"dark-grey-line\">
\t\t\t\t\t\t<p>Save this page as confirmation.
\t\t\t\t\t\t</p>
\t\t\t\t\t\t<div class=\"order-summary flex-column\">
\t\t\t\t\t\t\t<p>Order #:
\t\t\t\t\t\t\t\t";
        // line 80
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "order_number", []), "html", null, true);
        echo "</p>
\t\t\t\t\t\t\t<p>Total: \$";
        // line 81
        echo twig_escape_filter($this->env, $this->getAttribute(($context["order"] ?? null), "amount", []), "html", null, true);
        echo "</p>
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t<p>Items:
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<div class=\"y-scroll-div\" style=\"max-height:30vh\">
\t\t\t\t\t\t\t\t";
        // line 86
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["order_items"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 87
            echo "\t\t\t\t\t\t\t\t\t<div class=\"flex-row order-item-row\">
\t\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 88
            echo call_user_func_array($this->env->getFunction('asset')->getCallable(), [("img/store/" . $this->getAttribute($context["item"], "img_link", []))]);
            echo "\">
\t\t\t\t\t\t\t\t\t\t<p style=\"margin-left:10px;\">";
            // line 89
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", []), "html", null, true);
            echo "</p>
\t\t\t\t\t\t\t\t\t\t<p style=\"margin-left:auto;margin-right:10px;opacity:.6\">";
            // line 90
            ((($this->getAttribute($context["item"], "quantity", []) > 1)) ? (print (twig_escape_filter($this->env, ("x" . $this->getAttribute($context["item"], "quantity", [])), "html", null, true))) : (print ("")));
            echo "</p>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 93
        echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<hr class=\"dark-grey-line\" style=\"margin-top:auto;\">
\t\t\t\t\t\t<p style=\"width:65vw;font-style:italic;font-weight:normal;margin-top:20px;\">Making music has always been my passion, and now you are part of the reason I get to keep doing it, so thank you!<br>
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\tEvery order is hand-packed and shipped by me personally so I look forward to sending you yours! Keep on keeping on :)
\t\t\t\t\t\t\t<br><br><span style=\"font-family:script;float:right;margin-right:10vw;font-size:150%;\">- Isaac</span>
\t\t\t\t\t\t</p>
\t\t\t\t\t\t<hr class=\"dark-grey-line\" style=\"margin-top:20px;margin-bottom:25px;\">

\t\t\t\t\t\t<div class=\"socials flex-row\">
\t\t\t\t\t\t\t<p style=\"margin-right:10px;font-style:italic;opacity:.3\">Stay Connected with me!</p>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"";
        // line 105
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.instagram"]), "html", null, true);
        echo "\">d</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"";
        // line 106
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.facebook"]), "html", null, true);
        echo "\">c</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"";
        // line 107
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.youtube"]), "html", null, true);
        echo "\">w</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"";
        // line 108
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.spotify"]), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t<svg viewbox=\"0 0 2903 2903\" width=\"26\" height=\"26\">
\t\t\t\t\t\t\t\t\t<style>
\t\t\t\t\t\t\t\t\t\t.st0 {
\t\t\t\t\t\t\t\t\t\t\tfill: rgba(0, 0, 0, 0.809);
\t\t\t\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t\t\t</style><path class=\"st0\" d=\"M1465.5 0C656.1 0 0 656.1 0 1465.5S656.1 2931 1465.5 2931 2931 2274.9 2931 1465.5C2931 656.2 2274.9.1 1465.5 0zm672.1 2113.6c-26.3 43.2-82.6 56.7-125.6 30.4-344.1-210.3-777.3-257.8-1287.4-141.3-49.2 11.3-98.2-19.5-109.4-68.7-11.3-49.2 19.4-98.2 68.7-109.4C1242.1 1697.1 1721 1752 2107.3 1988c43 26.5 56.7 82.6 30.3 125.6zm179.3-398.9c-33.1 53.8-103.5 70.6-157.2 37.6-393.8-242.1-994.4-312.2-1460.3-170.8-60.4 18.3-124.2-15.8-142.6-76.1-18.2-60.4 15.9-124.1 76.2-142.5 532.2-161.5 1193.9-83.3 1646.2 194.7 53.8 33.1 70.8 103.4 37.7 157.1zm15.4-415.6c-472.4-280.5-1251.6-306.3-1702.6-169.5-72.4 22-149-18.9-170.9-91.3-21.9-72.4 18.9-149 91.4-171 517.7-157.1 1378.2-126.8 1922 196 65.1 38.7 86.5 122.8 47.9 187.8-38.5 65.2-122.8 86.7-187.8 48z\"/></svg>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"";
        // line 116
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.itunes"]), "html", null, true);
        echo "\">h</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"";
        // line 117
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.twitter"]), "html", null, true);
        echo "\">o</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/store/order.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  252 => 117,  248 => 116,  237 => 108,  233 => 107,  229 => 106,  225 => 105,  211 => 93,  202 => 90,  198 => 89,  194 => 88,  191 => 87,  187 => 86,  179 => 81,  175 => 80,  165 => 73,  154 => 65,  145 => 59,  141 => 58,  130 => 50,  126 => 49,  122 => 48,  118 => 47,  105 => 36,  96 => 33,  92 => 32,  88 => 31,  85 => 30,  81 => 29,  73 => 24,  69 => 23,  59 => 16,  49 => 8,  46 => 7,  41 => 5,  39 => 3,  37 => 2,  35 => 1,  29 => 5,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% set pageTitle = \"Order\" %}
{% set pageBackLink = false %}
{% set customFooter = false %}

{% extends \"_layout/site.twig\" %}

{% block content %}
\t<div class=\"background sd-white-back\">
\t\t<div class=\"mobile_content white\">
\t\t\t<div class=\"y-scroll-div full_screen_scroll_footer\">
\t\t\t\t<div class=\"flex-column order-columns\">
\t\t\t\t\t<h1>Congratulations!</h1>
\t\t\t\t\t<h2>Your order has been placed!</h2>
\t\t\t\t\t<hr class=\"dark-grey-line\">
\t\t\t\t\t<h3>Thank you
\t\t\t\t\t\t{{order.first_name}}
\t\t\t\t\t\tfor your support!</h3>
\t\t\t\t\t<hr class=\"dark-grey-line\">
\t\t\t\t\t<p>Save this page as confirmation.
\t\t\t\t\t</p>
\t\t\t\t\t<div class=\"order-summary flex-column\">
\t\t\t\t\t\t<p>Order #:
\t\t\t\t\t\t\t{{order.order_number}}</p>
\t\t\t\t\t\t<p>Total: \${{order.amount}}</p>
\t\t\t\t\t\t<br>
\t\t\t\t\t\t<p>Items:
\t\t\t\t\t\t</p>
\t\t\t\t\t\t<div class=\"y-scroll-div\" style=\"max-height:30vh\">
\t\t\t\t\t\t\t{% for item in order_items %}
\t\t\t\t\t\t\t\t<div class=\"flex-row order-item-row\">
\t\t\t\t\t\t\t\t\t<img src=\"{{asset('img/store/' ~ item.img_link)}}\">
\t\t\t\t\t\t\t\t\t<p style=\"margin-left:10px;\">{{item.name}}</p>
\t\t\t\t\t\t\t\t\t<p style=\"margin-left:auto;margin-right:10px;opacity:.6\">{{item.quantity > 1 ? 'x' ~ item.quantity : ''}}</p>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<hr class=\"dark-grey-line\" style=\"margin-top:auto;\">
\t\t\t\t\t<p style=\"width:85vw;font-style:italic;font-weight:normal;margin-top:20px;\">Making music has always been my passion, and now you are part of the reason I get to keep doing it, so thank you!<br>
\t\t\t\t\t\t<br>
\t\t\t\t\t\tEvery order is hand-packed and shipped by me personally so I look forward to sending you yours! Keep on keeping on :)
\t\t\t\t\t\t<br><br><span style=\"font-family:script;float:right;margin-right:10vw;font-size:150%;\">- Isaac</span>
\t\t\t\t\t</p>
\t\t\t\t\t<hr class=\"dark-grey-line\" style=\"margin-top:20px;margin-bottom:25px;\">
                    <div class=\"socials flex-row\">
\t\t\t\t\t\t\t<p style=\"margin-right:10px;font-style:italic;opacity:.3\">Stay Connected with me!</p>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"{{config('links.instagram')}}\">d</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"{{config('links.facebook')}}\">c</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"{{config('links.youtube')}}\">w</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"{{config('links.spotify')}}\">
\t\t\t\t\t\t\t\t<svg viewbox=\"0 0 2903 2903\" width=\"26\" height=\"26\">
\t\t\t\t\t\t\t\t\t<style>
\t\t\t\t\t\t\t\t\t\t.st0 {
\t\t\t\t\t\t\t\t\t\t\tfill: rgba(0, 0, 0, 0.809);
\t\t\t\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t\t\t</style><path class=\"st0\" d=\"M1465.5 0C656.1 0 0 656.1 0 1465.5S656.1 2931 1465.5 2931 2931 2274.9 2931 1465.5C2931 656.2 2274.9.1 1465.5 0zm672.1 2113.6c-26.3 43.2-82.6 56.7-125.6 30.4-344.1-210.3-777.3-257.8-1287.4-141.3-49.2 11.3-98.2-19.5-109.4-68.7-11.3-49.2 19.4-98.2 68.7-109.4C1242.1 1697.1 1721 1752 2107.3 1988c43 26.5 56.7 82.6 30.3 125.6zm179.3-398.9c-33.1 53.8-103.5 70.6-157.2 37.6-393.8-242.1-994.4-312.2-1460.3-170.8-60.4 18.3-124.2-15.8-142.6-76.1-18.2-60.4 15.9-124.1 76.2-142.5 532.2-161.5 1193.9-83.3 1646.2 194.7 53.8 33.1 70.8 103.4 37.7 157.1zm15.4-415.6c-472.4-280.5-1251.6-306.3-1702.6-169.5-72.4 22-149-18.9-170.9-91.3-21.9-72.4 18.9-149 91.4-171 517.7-157.1 1378.2-126.8 1922 196 65.1 38.7 86.5 122.8 47.9 187.8-38.5 65.2-122.8 86.7-187.8 48z\"/></svg>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"{{config('links.itunes')}}\">h</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"{{config('links.twitter')}}\">o</a>
\t\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"desktop_content back-white\">
\t\t\t<img class=\"back_img\" src=\"{{asset('img/backgrounds/sd-back-rainbow.png')}}\">
\t\t\t<div class=\"desktop-scroll\">
\t\t\t\t<div class=\"y-scroll-div order_info_div\">
\t\t\t\t\t<div class=\"flex-column order-columns\">
\t\t\t\t\t\t<h1>Congratulations!</h1>
\t\t\t\t\t\t<h2>Your order has been placed!</h2>
\t\t\t\t\t\t<hr class=\"dark-grey-line\">
\t\t\t\t\t\t<h3>Thank you
\t\t\t\t\t\t\t{{order.first_name}}
\t\t\t\t\t\t\tfor your support!</h3>
\t\t\t\t\t\t<hr class=\"dark-grey-line\">
\t\t\t\t\t\t<p>Save this page as confirmation.
\t\t\t\t\t\t</p>
\t\t\t\t\t\t<div class=\"order-summary flex-column\">
\t\t\t\t\t\t\t<p>Order #:
\t\t\t\t\t\t\t\t{{order.order_number}}</p>
\t\t\t\t\t\t\t<p>Total: \${{order.amount}}</p>
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t<p>Items:
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<div class=\"y-scroll-div\" style=\"max-height:30vh\">
\t\t\t\t\t\t\t\t{% for item in order_items %}
\t\t\t\t\t\t\t\t\t<div class=\"flex-row order-item-row\">
\t\t\t\t\t\t\t\t\t\t<img src=\"{{asset('img/store/' ~ item.img_link)}}\">
\t\t\t\t\t\t\t\t\t\t<p style=\"margin-left:10px;\">{{item.name}}</p>
\t\t\t\t\t\t\t\t\t\t<p style=\"margin-left:auto;margin-right:10px;opacity:.6\">{{item.quantity > 1 ? 'x' ~ item.quantity : ''}}</p>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<hr class=\"dark-grey-line\" style=\"margin-top:auto;\">
\t\t\t\t\t\t<p style=\"width:65vw;font-style:italic;font-weight:normal;margin-top:20px;\">Making music has always been my passion, and now you are part of the reason I get to keep doing it, so thank you!<br>
\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\tEvery order is hand-packed and shipped by me personally so I look forward to sending you yours! Keep on keeping on :)
\t\t\t\t\t\t\t<br><br><span style=\"font-family:script;float:right;margin-right:10vw;font-size:150%;\">- Isaac</span>
\t\t\t\t\t\t</p>
\t\t\t\t\t\t<hr class=\"dark-grey-line\" style=\"margin-top:20px;margin-bottom:25px;\">

\t\t\t\t\t\t<div class=\"socials flex-row\">
\t\t\t\t\t\t\t<p style=\"margin-right:10px;font-style:italic;opacity:.3\">Stay Connected with me!</p>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"{{config('links.instagram')}}\">d</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"{{config('links.facebook')}}\">c</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"{{config('links.youtube')}}\">w</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"{{config('links.spotify')}}\">
\t\t\t\t\t\t\t\t<svg viewbox=\"0 0 2903 2903\" width=\"26\" height=\"26\">
\t\t\t\t\t\t\t\t\t<style>
\t\t\t\t\t\t\t\t\t\t.st0 {
\t\t\t\t\t\t\t\t\t\t\tfill: rgba(0, 0, 0, 0.809);
\t\t\t\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t\t\t</style><path class=\"st0\" d=\"M1465.5 0C656.1 0 0 656.1 0 1465.5S656.1 2931 1465.5 2931 2931 2274.9 2931 1465.5C2931 656.2 2274.9.1 1465.5 0zm672.1 2113.6c-26.3 43.2-82.6 56.7-125.6 30.4-344.1-210.3-777.3-257.8-1287.4-141.3-49.2 11.3-98.2-19.5-109.4-68.7-11.3-49.2 19.4-98.2 68.7-109.4C1242.1 1697.1 1721 1752 2107.3 1988c43 26.5 56.7 82.6 30.3 125.6zm179.3-398.9c-33.1 53.8-103.5 70.6-157.2 37.6-393.8-242.1-994.4-312.2-1460.3-170.8-60.4 18.3-124.2-15.8-142.6-76.1-18.2-60.4 15.9-124.1 76.2-142.5 532.2-161.5 1193.9-83.3 1646.2 194.7 53.8 33.1 70.8 103.4 37.7 157.1zm15.4-415.6c-472.4-280.5-1251.6-306.3-1702.6-169.5-72.4 22-149-18.9-170.9-91.3-21.9-72.4 18.9-149 91.4-171 517.7-157.1 1378.2-126.8 1922 196 65.1 38.7 86.5 122.8 47.9 187.8-38.5 65.2-122.8 86.7-187.8 48z\"/></svg>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"{{config('links.itunes')}}\">h</a>
\t\t\t\t\t\t\t<a target=\"_blank\" href=\"{{config('links.twitter')}}\">o</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
{% endblock %}
", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/store/order.twig", "");
    }
}
