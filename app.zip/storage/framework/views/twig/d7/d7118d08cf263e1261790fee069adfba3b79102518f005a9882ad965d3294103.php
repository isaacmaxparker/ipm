<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\Users\isaac\Documents\Projects\ipm\resources\views/index/home.twig */
class __TwigTemplate_1c35f0b48c9e93155340b142bbcdac2b63d1143055c356d0c7982475cfd8e107 extends TwigBridge\Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "_layout/site.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["pageTitle"] = "Isaac Parker Music";
        // line 3
        $this->parent = $this->loadTemplate("_layout/site.twig", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/index/home.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        // line 6
        echo "\t<div class=\"background sd-back slowload\" data-module=\"slowload\">
\t\t<div class=\"mobile_content full_screen_scroll_footer\">
\t\t</div>
\t\t<div class=\"desktop_content full_screen_scroll_footer\" data-module=\"slowload\">
\t\t\t<div class=\"y-scroll-div fullscreen\">
\t\t\t\t<div class=\"homepage_cards flex-column\">
\t\t\t\t\t<div class=\"homepage_card flex-row\">
\t\t\t\t\t\t<img src=\"";
        // line 13
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]), "html", null, true);
        echo "backgrounds/ice-cream-card-back-left.png\" class=\"back_img\"/>
\t\t\t\t\t\t<a href=\"";
        // line 14
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["music::release", [0 => $this->getAttribute($this->getAttribute(($context["latest"] ?? null), 0, [], "array"), "id", [])]]);
        echo "\">
\t\t\t\t\t\t\t<div class=\"card_title\">
\t\t\t\t\t\t\t\tListen
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<div class=\"listen_images flex-row\">
\t\t\t\t\t\t\t<a href=\"";
        // line 20
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["music::release", [0 => $this->getAttribute($this->getAttribute(($context["latest"] ?? null), 1, [], "array"), "id", [])]]);
        echo "\" class=\"first-child\"><img src=\"";
        echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/album_arts/") . $this->getAttribute($this->getAttribute(($context["latest"] ?? null), 1, [], "array"), "img_link", [])), "html", null, true);
        echo "\"></a>
\t\t\t\t\t\t\t<a href=\"";
        // line 21
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["music::release", [0 => $this->getAttribute($this->getAttribute(($context["latest"] ?? null), 0, [], "array"), "id", [])]]);
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/album_arts/") . $this->getAttribute($this->getAttribute(($context["latest"] ?? null), 0, [], "array"), "img_link", [])), "html", null, true);
        echo "\"></a>
\t\t\t\t\t\t\t<a href=\"";
        // line 22
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["music::release", [0 => $this->getAttribute($this->getAttribute(($context["latest"] ?? null), 2, [], "array"), "id", [])]]);
        echo "\" class=\"last-child\"><img src=\"";
        echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/album_arts/") . $this->getAttribute($this->getAttribute(($context["latest"] ?? null), 2, [], "array"), "img_link", [])), "html", null, true);
        echo "\"></a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"homepage_card flex-row right_card\">
\t\t\t\t\t\t<img src=\"";
        // line 26
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]), "html", null, true);
        echo "backgrounds/cb-card-back-right.png}}\" class=\"back_img\">
\t\t\t\t\t\t<div
\t\t\t\t\t\t\tclass=\"listen_images\">
\t\t\t\t\t\t\t";
        // line 30
        echo "\t\t\t\t\t\t\t<a href=\"";
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["store::product", [0 => $this->getAttribute($this->getAttribute(($context["featured"] ?? null), 0, [], "array"), "id", [])]]);
        echo "\"><img src=\"";
        echo call_user_func_array($this->env->getFunction('asset')->getCallable(), [((("img/store/" . $this->getAttribute($this->getAttribute(($context["featured"] ?? null), 0, [], "array"), "type", [])) . "/") . $this->getAttribute($this->getAttribute(($context["featured"] ?? null), 0, [], "array"), "img_link", []))]);
        echo "\"></a>
\t\t\t\t\t\t\t";
        // line 32
        echo "\t\t\t\t\t\t</div>
\t\t\t\t\t\t<a href=\"";
        // line 33
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["store::catalog"]);
        echo "\">
\t\t\t\t\t\t\t<div class=\"card_title_right\">
\t\t\t\t\t\t\t\tShop
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"homepage_card flex-row\">
\t\t\t\t\t\t<img src=\"";
        // line 40
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]), "html", null, true);
        echo "backgrounds/corn-card-back-left.png}}\" class=\"back_img\"/>
\t\t\t\t\t\t<a href=\"https://www.youtube.com/watch?v=n3SxiyciHak&list=PLjRMKXXyQLKu5f-as4CA5iGTbb59pTOAw\">
\t\t\t\t\t\t\t<div class=\"card_title\">
\t\t\t\t\t\t\t\tWatch
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<div class=\"flex-row watch_card_video_div\">
\t\t\t\t\t\t\t<a href=\"https://www.youtube.com/watch?v=n3SxiyciHak&list=PLjRMKXXyQLKu5f-as4CA5iGTbb59pTOAw\">
\t\t\t\t\t\t\t\t<div class=\"watch_card_video\">
\t\t\t\t\t\t\t\t\t<video id=\"gallery_video\" autoplay loop muted playsinline class=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "theme_color", []), "html", null, true);
        echo "-border invisible slowload\" width=\"100%\" height=\"100%\">
\t\t\t\t\t\t\t\t\t\t<source src=\"";
        // line 50
        echo call_user_func_array($this->env->getFunction('asset')->getCallable(), ["img/videos/homepage_yt_summary.webm"]);
        echo "\" type=\"video/webm\">
\t\t\t\t\t\t\t\t\t\t<source src=\"";
        // line 51
        echo call_user_func_array($this->env->getFunction('asset')->getCallable(), ["img/videos/homepage_yt_summary.mp4"]);
        echo "\" type=\"video/mp4\">
\t\t\t\t\t\t\t\t\t</video>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
";
    }

    public function getTemplateName()
    {
        return "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/index/home.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  134 => 51,  130 => 50,  126 => 49,  114 => 40,  104 => 33,  101 => 32,  94 => 30,  88 => 26,  79 => 22,  73 => 21,  67 => 20,  58 => 14,  54 => 13,  45 => 6,  42 => 5,  37 => 3,  35 => 1,  29 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% set pageTitle = \"Isaac Parker Music\" %}

{% extends \"_layout/site.twig\" %}

{% block content %}
\t<div class=\"background sd-back slowload\" data-module=\"slowload\">
\t\t<div class=\"mobile_content full_screen_scroll_footer\">
\t\t</div>
\t\t<div class=\"desktop_content full_screen_scroll_footer\" data-module=\"slowload\">
\t\t\t<div class=\"y-scroll-div fullscreen\">
\t\t\t\t<div class=\"homepage_cards flex-column\">
\t\t\t\t\t<div class=\"homepage_card flex-row\">
\t\t\t\t\t\t<img src=\"{{config('links.s3_img_link')}}backgrounds/ice-cream-card-back-left.png\" class=\"back_img\"/>
\t\t\t\t\t\t<a href=\"{{route('music::release',[latest[0].id])}}\">
\t\t\t\t\t\t\t<div class=\"card_title\">
\t\t\t\t\t\t\t\tListen
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<div class=\"listen_images flex-row\">
\t\t\t\t\t\t\t<a href=\"{{route('music::release',[latest[1].id])}}\" class=\"first-child\"><img src=\"{{config('links.s3_img_link') ~ 'releases/album_arts/' ~ latest[1].img_link}}\"></a>
\t\t\t\t\t\t\t<a href=\"{{route('music::release',[latest[0].id])}}\"><img src=\"{{config('links.s3_img_link') ~ 'releases/album_arts/' ~ latest[0].img_link}}\"></a>
\t\t\t\t\t\t\t<a href=\"{{route('music::release',[latest[2].id])}}\" class=\"last-child\"><img src=\"{{config('links.s3_img_link') ~ 'releases/album_arts/' ~ latest[2].img_link}}\"></a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"homepage_card flex-row right_card\">
\t\t\t\t\t\t<img src=\"{{config('links.s3_img_link')}}backgrounds/cb-card-back-right.png}}\" class=\"back_img\">
\t\t\t\t\t\t<div
\t\t\t\t\t\t\tclass=\"listen_images\">
\t\t\t\t\t\t\t{# <a href=\"{{route('music::release',[latest[1].id])}}\" class=\"first-child\"><img src=\"{{asset('img/releases/album_arts/' ~ latest[1].img_link)}}\"></a> #}
\t\t\t\t\t\t\t<a href=\"{{route('store::product',[featured[0].id])}}\"><img src=\"{{asset('img/store/' ~ featured[0].type ~ '/' ~ featured[0].img_link)}}\"></a>
\t\t\t\t\t\t\t{# <a href=\"{{route('music::release',[latest[2].id])}}\" class=\"last-child\"><img src=\"{{asset('img/releases/album_arts/' ~ latest[2].img_link)}}\"> #}
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<a href=\"{{route('store::catalog')}}\">
\t\t\t\t\t\t\t<div class=\"card_title_right\">
\t\t\t\t\t\t\t\tShop
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"homepage_card flex-row\">
\t\t\t\t\t\t<img src=\"{{config('links.s3_img_link')}}backgrounds/corn-card-back-left.png}}\" class=\"back_img\"/>
\t\t\t\t\t\t<a href=\"https://www.youtube.com/watch?v=n3SxiyciHak&list=PLjRMKXXyQLKu5f-as4CA5iGTbb59pTOAw\">
\t\t\t\t\t\t\t<div class=\"card_title\">
\t\t\t\t\t\t\t\tWatch
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<div class=\"flex-row watch_card_video_div\">
\t\t\t\t\t\t\t<a href=\"https://www.youtube.com/watch?v=n3SxiyciHak&list=PLjRMKXXyQLKu5f-as4CA5iGTbb59pTOAw\">
\t\t\t\t\t\t\t\t<div class=\"watch_card_video\">
\t\t\t\t\t\t\t\t\t<video id=\"gallery_video\" autoplay loop muted playsinline class=\"{{release.theme_color}}-border invisible slowload\" width=\"100%\" height=\"100%\">
\t\t\t\t\t\t\t\t\t\t<source src=\"{{asset('img/videos/homepage_yt_summary.webm')}}\" type=\"video/webm\">
\t\t\t\t\t\t\t\t\t\t<source src=\"{{asset('img/videos/homepage_yt_summary.mp4')}}\" type=\"video/mp4\">
\t\t\t\t\t\t\t\t\t</video>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
{% endblock %}
", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/index/home.twig", "");
    }
}
