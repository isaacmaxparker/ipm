<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\Users\isaac\Documents\Projects\ipm\resources\views/music/catalog.twig */
class __TwigTemplate_5f6471ff18589cad739d0afde9c01d360d266014f4c2f5d8d2ae1a38c1f0fa42 extends TwigBridge\Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "_layout/site.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["pageTitle"] = "Discography";
        // line 2
        $context["customFooter"] = true;
        // line 3
        $this->parent = $this->loadTemplate("_layout/site.twig", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/music/catalog.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        // line 6
        echo "<div class=\"background sd-back\">
    <div class=\"mobile_content fullscreen\">
        <div class=\"y-scroll-div\">
            <div class=\"catalog_grid\">
                ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["releases"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["release"]) {
            // line 11
            echo "                    <a href=\"";
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["music::release", [0 => $this->getAttribute($context["release"], "id", [])]]);
            echo "\">
                        <div class=\"catalog_grid_card\">
                            <img src=\"";
            // line 13
            echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/album_arts/") . $this->getAttribute($context["release"], "img_link", [])), "html", null, true);
            echo "\">
                            <div class=\"card_spacer ";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($context["release"], "theme_color", []), "html", null, true);
            echo "-dark-back\"></div>
                            <p class=\"label\">";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($context["release"], "title", []), "html", null, true);
            echo " <span class=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["release"], "theme_color", []), "html", null, true);
            echo "-text\">(";
            echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["release"], "release_date", []), 0, 4), "html", null, true);
            echo ")</span></p>
                        </div>
                    </a>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['release'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "            </div>
        </div>
    </div>
     <div class=\"desktop_content fullscreen\">
        <div class=\"y-scroll-div\">
            <div class=\"catalog_grid\">
                ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["releases"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["release"]) {
            // line 26
            echo "                    <a href=\"";
            echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["music::release", [0 => $this->getAttribute($context["release"], "id", [])]]);
            echo "\">
                        <div class=\"catalog_grid_card\">
                            <img src=\"";
            // line 28
            echo twig_escape_filter($this->env, ((call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]) . "releases/album_arts/") . $this->getAttribute($context["release"], "img_link", [])), "html", null, true);
            echo "\">
                            <div class=\"card_spacer ";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["release"], "theme_color", []), "html", null, true);
            echo "-dark-back\"></div>
                            <p class=\"label\">";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["release"], "title", []), "html", null, true);
            echo " <span class=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["release"], "theme_color", []), "html", null, true);
            echo "-text\">(";
            echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["release"], "release_date", []), 0, 4), "html", null, true);
            echo ")</span></p>
                            <div class=\"catalog_desc ";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["release"], "theme_color", []), "html", null, true);
            echo "-dark-back\">
                                <p>";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["release"], "title", []), "html", null, true);
            echo "</p>
                                <hr>
                                ";
            // line 34
            if ((twig_length_filter($this->env, $this->getAttribute($context["release"], "description", [])) > 200)) {
                // line 35
                echo "                                    <p>";
                echo twig_slice($this->env, $this->getAttribute($context["release"], "description", []), 0, 200);
                echo "...</p>
                                ";
            } else {
                // line 37
                echo "                                     <p>";
                echo $this->getAttribute($context["release"], "description", []);
                echo "</p>
                                ";
            }
            // line 39
            echo "                            </div>
                        </div>
                    </a>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['release'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "            </div>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/music/catalog.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  151 => 43,  142 => 39,  136 => 37,  130 => 35,  128 => 34,  123 => 32,  119 => 31,  111 => 30,  107 => 29,  103 => 28,  97 => 26,  93 => 25,  85 => 19,  71 => 15,  67 => 14,  63 => 13,  57 => 11,  53 => 10,  47 => 6,  44 => 5,  39 => 3,  37 => 2,  35 => 1,  29 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% set pageTitle = \"Discography\" %}
{% set customFooter = true %}
{% extends \"_layout/site.twig\" %}

{% block content %}
<div class=\"background sd-back\">
    <div class=\"mobile_content fullscreen\">
        <div class=\"y-scroll-div\">
            <div class=\"catalog_grid\">
                {% for release in releases %}
                    <a href=\"{{route('music::release',[release.id])}}\">
                        <div class=\"catalog_grid_card\">
                            <img src=\"{{config('links.s3_img_link') ~ 'releases/album_arts/' ~ release.img_link}}\">
                            <div class=\"card_spacer {{release.theme_color}}-dark-back\"></div>
                            <p class=\"label\">{{release.title}} <span class=\"{{release.theme_color}}-text\">({{release.release_date|slice(0,4)}})</span></p>
                        </div>
                    </a>
                {% endfor %}
            </div>
        </div>
    </div>
     <div class=\"desktop_content fullscreen\">
        <div class=\"y-scroll-div\">
            <div class=\"catalog_grid\">
                {% for release in releases %}
                    <a href=\"{{route('music::release',[release.id])}}\">
                        <div class=\"catalog_grid_card\">
                            <img src=\"{{config('links.s3_img_link') ~ 'releases/album_arts/' ~ release.img_link}}\">
                            <div class=\"card_spacer {{release.theme_color}}-dark-back\"></div>
                            <p class=\"label\">{{release.title}} <span class=\"{{release.theme_color}}-text\">({{release.release_date|slice(0,4)}})</span></p>
                            <div class=\"catalog_desc {{release.theme_color}}-dark-back\">
                                <p>{{release.title}}</p>
                                <hr>
                                {% if release.description|length > 200 %}
                                    <p>{{release.description|slice(0,200)|raw}}...</p>
                                {% else %}
                                     <p>{{release.description|raw}}</p>
                                {% endif %}
                            </div>
                        </div>
                    </a>
                {% endfor %}
            </div>
        </div>
    </div>
</div>
{% endblock %}", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/music/catalog.twig", "");
    }
}
