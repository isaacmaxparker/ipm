<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layout/_snippets/head.twig */
class __TwigTemplate_ee6d6069674e3916d3e0332ed7e8832d007b5a9b9521ea720ec18bc144d5e91e extends TwigBridge\Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<meta charset=\"utf-8\">
 
<title>Isaac Parker Music</title>
<meta name=\"description\" content=\"\"/>
 
<!-- icons -->
<link rel=\"apple-touch-icon\" sizes=\"57x57\" href=\"/assets/img/icons/apple-touch-icon-57x57.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"60x60\" href=\"/assets/img/icons/apple-touch-icon-60x60.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"72x72\" href=\"/assets/img/icons/apple-touch-icon-72x72.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"76x76\" href=\"/assets/img/icons/apple-touch-icon-76x76.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"114x114\" href=\"/assets/img/icons/apple-touch-icon-114x114.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"120x120\" href=\"/assets/img/icons/apple-touch-icon-120x120.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"144x144\" href=\"/assets/img/icons/apple-touch-icon-144x144.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"152x152\" href=\"/assets/img/icons/apple-touch-icon-152x152.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"/assets/img/icons/apple-touch-icon-180x180.png\"/>
";
        // line 21
        echo "<meta name=\"msapplication-TileColor\" content=\"#ffffff\"/>
<meta name=\"msapplication-TileImage\" content=\"/assets/img/icons/mstile-144x144.png\"/>
<meta name=\"theme-color\" content=\"#ffffff\"/>
<meta name=\"csrf-token\" content=\"";
        // line 24
        echo call_user_func_array($this->env->getFunction('csrf_token')->getCallable(), []);
        echo "\">

<!-- /icons -->
 
<!-- mobile meta -->
<meta name=\"HandheldFriendly\" content=\"True\"/>
<meta name=\"MobileOptimized\" content=\"320\"/>
<meta name=\"viewport\" content=\"width=device-width, minimum-scale=1.0\">
<!-- /mobile meta -->
 
<!-- jquery ui -->
 <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js\"></script>
 <link rel=\"stylesheet\" href=\"https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css\">
 <script src=\"https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js\"></script>

<link rel=\"stylesheet\" href=\"";
        // line 39
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('mix')->getCallable(), ["css/style.css"]), "html", null, true);
        echo "\" type=\"text/css\"/>
<link rel=\"stylesheet\" href=\"";
        // line 40
        echo call_user_func_array($this->env->getFunction('asset')->getCallable(), ["css/fonts.css"]);
        echo "\" type=\"text/css\"/>
<script>
function toggleClass(div, className){
    if(div.classList.contains(className)){
        div.classList.remove(className)
    }else{
        div.classList.add(className)
    }
}
</script>";
    }

    public function getTemplateName()
    {
        return "_layout/_snippets/head.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 40,  70 => 39,  52 => 24,  47 => 21,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("<meta charset=\"utf-8\">
 
<title>Isaac Parker Music</title>
<meta name=\"description\" content=\"\"/>
 
<!-- icons -->
<link rel=\"apple-touch-icon\" sizes=\"57x57\" href=\"/assets/img/icons/apple-touch-icon-57x57.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"60x60\" href=\"/assets/img/icons/apple-touch-icon-60x60.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"72x72\" href=\"/assets/img/icons/apple-touch-icon-72x72.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"76x76\" href=\"/assets/img/icons/apple-touch-icon-76x76.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"114x114\" href=\"/assets/img/icons/apple-touch-icon-114x114.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"120x120\" href=\"/assets/img/icons/apple-touch-icon-120x120.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"144x144\" href=\"/assets/img/icons/apple-touch-icon-144x144.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"152x152\" href=\"/assets/img/icons/apple-touch-icon-152x152.png\"/>
<link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"/assets/img/icons/apple-touch-icon-180x180.png\"/>
{# <link rel=\"icon\" type=\"image/png\" href=\"/assets/img/icons/favicon-32x32.png\" sizes=\"32x32\"/>
<link rel=\"icon\" type=\"image/png\" href=\"/assets/img/icons/android-chrome-192x192.png\" sizes=\"192x192\"/>
<link rel=\"icon\" type=\"image/png\" href=\"/assets/img/icons/favicon-96x96.png\" sizes=\"96x96\"/>
<link rel=\"icon\" type=\"image/png\" href=\"/assets/img/icons/favicon-16x16.png\" sizes=\"16x16\"/> #}
{# <link rel=\"manifest\" href=\"/assets/img/icons/manifest.json\"/> #}
<meta name=\"msapplication-TileColor\" content=\"#ffffff\"/>
<meta name=\"msapplication-TileImage\" content=\"/assets/img/icons/mstile-144x144.png\"/>
<meta name=\"theme-color\" content=\"#ffffff\"/>
<meta name=\"csrf-token\" content=\"{{ csrf_token() }}\">

<!-- /icons -->
 
<!-- mobile meta -->
<meta name=\"HandheldFriendly\" content=\"True\"/>
<meta name=\"MobileOptimized\" content=\"320\"/>
<meta name=\"viewport\" content=\"width=device-width, minimum-scale=1.0\">
<!-- /mobile meta -->
 
<!-- jquery ui -->
 <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js\"></script>
 <link rel=\"stylesheet\" href=\"https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css\">
 <script src=\"https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js\"></script>

<link rel=\"stylesheet\" href=\"{{ mix('css/style.css') }}\" type=\"text/css\"/>
<link rel=\"stylesheet\" href=\"{{ asset('css/fonts.css') }}\" type=\"text/css\"/>
<script>
function toggleClass(div, className){
    if(div.classList.contains(className)){
        div.classList.remove(className)
    }else{
        div.classList.add(className)
    }
}
</script>", "_layout/_snippets/head.twig", "");
    }
}
