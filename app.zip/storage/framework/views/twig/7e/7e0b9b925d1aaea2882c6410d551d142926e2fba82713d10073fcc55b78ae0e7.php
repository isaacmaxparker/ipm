<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* C:\Users\isaac\Documents\Projects\ipm\resources\views/admin/releases/viewrelease.twig */
class __TwigTemplate_682c8df109e0165eed1a9f2acd258691d26a6c72adea91ebcc7c3ebe6012b8a3 extends TwigBridge\Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 6
        return "_layout/adminsite.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        if (($context["release"] ?? null)) {
            // line 2
            $context["pageTitle"] = "Edit Release";
        } else {
            // line 4
            $context["pageTitle"] = "New Release";
        }
        // line 6
        $this->parent = $this->loadTemplate("_layout/adminsite.twig", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/admin/releases/viewrelease.twig", 6);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 8
    public function block_content($context, array $blocks = [])
    {
        // line 9
        echo "\t<div class=\"header_content slowload\" data-module=\"slowload\">
\t\t<div class=\"back_img\"><img src=\"";
        // line 10
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('config')->getCallable(), ["links.s3_img_link"]), "html", null, true);
        echo "releases/backgrounds/cn-back.png\"></div>
\t\t<div class=\"admin_div edit_div flex-column\">

\t\t\t<div class=\"table\">
\t\t\t\t<form class=\"edit_form\" method=\"POST\" action=\"";
        // line 14
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["admin::saverelease", [0 => $this->getAttribute(($context["release"] ?? null), "id", [])]]);
        echo "\">
\t\t\t\t\t        ";
        // line 15
        echo csrf_field();
        echo "
                    <div class=\"y-scroll-div\">
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Release Title:<sup style=\"color:#b31010b8\">*</sup>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<input name=\"title\" required value='";
        // line 20
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "title", []), "html", null, true);
        echo "'>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Subtitle:</p>
\t\t\t\t\t\t\t<input name=\"subtitle\" value='";
        // line 24
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "subtitle", []), "html", null, true);
        echo "'>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Description:<sup style=\"color:#b31010b8\">*</sup>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<textarea name=\"description\" required>";
        // line 29
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "description", []), "html", null, true);
        echo "</textarea>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Release Date: (YYYY-MM-DD)<sup style=\"color:#b31010b8\">*</sup>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<input name=\"release_date\" required placeholder=\"YYYY-MM-DD\" value=";
        // line 34
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "release_date", []), "html", null, true);
        echo ">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Album Art Img Name:<sup style=\"color:#b31010b8\">*</sup>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<input name=\"img_link\" required value=";
        // line 39
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "img_link", []), "html", null, true);
        echo ">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Background Type:<sup style=\"color:#b31010b8\">*</sup>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<select name=\"background_type\" required value=";
        // line 44
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "background_type", []), "html", null, true);
        echo ">
\t\t\t\t\t\t\t\t<option value=\"video\">Video</option>
\t\t\t\t\t\t\t\t<option value=\"image\">Image</option>
\t\t\t\t\t\t\t</select>

\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Background Image Name:<sup style=\"color:#b31010b8\">*</sup>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<input name=\"back_img_link\" required value=";
        // line 53
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "back_img_link", []), "html", null, true);
        echo ">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Gallery Img Link:</p>
\t\t\t\t\t\t\t<input name=\"gallery_img_link\" value=";
        // line 57
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "gallery_img_link", []), "html", null, true);
        echo ">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Theme Color:<sup style=\"color:#b31010b8\">*</sup>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<select name=\"theme_color\" required>
\t\t\t\t\t\t\t\t";
        // line 63
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["colors"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["color"]) {
            // line 64
            echo "\t\t\t\t\t\t\t\t\t";
            $context["selected"] = "";
            // line 65
            echo "\t\t\t\t\t\t\t\t\t";
            if (($this->getAttribute(($context["release"] ?? null), "theme_color", []) == $context["color"])) {
                // line 66
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context["selected"] = "selected";
                // line 67
                echo "\t\t\t\t\t\t\t\t\t";
            }
            // line 68
            echo "\t\t\t\t\t\t\t\t\t<option value=\"";
            echo twig_escape_filter($this->env, $context["color"], "html", null, true);
            echo "\" ";
            echo twig_escape_filter($this->env, ($context["selected"] ?? null), "html", null, true);
            echo ">";
            echo twig_escape_filter($this->env, $context["color"], "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['color'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 70
        echo "\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Youtube Link:</p>
\t\t\t\t\t\t\t<input name=\"youtube_link\" value=";
        // line 74
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "youtube_link", []), "html", null, true);
        echo ">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Spotify Link:</p>
\t\t\t\t\t\t\t<input name=\"spotify_link\" value=";
        // line 78
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "spotify_link", []), "html", null, true);
        echo ">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>iTunes Link:</p>
\t\t\t\t\t\t\t<input name=\"itunes_link\" value=";
        // line 82
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "itunes_link", []), "html", null, true);
        echo ">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Youtube Music Link:</p>
\t\t\t\t\t\t\t<input name=\"youtube_music_link\" value=";
        // line 86
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "youtube_link", []), "html", null, true);
        echo ">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Amazon Link:</p>
\t\t\t\t\t\t\t<input name=\"amazon_link\" value=";
        // line 90
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "amazon_link", []), "html", null, true);
        echo ">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>iHeartRadio Link:</p>
\t\t\t\t\t\t\t<input name=\"iheartradio_link\" value=";
        // line 94
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "iheartradio_link", []), "html", null, true);
        echo ">
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Youtube Link:</p>
\t\t\t\t\t\t\t<input name=\"distrokid_link\" value=";
        // line 98
        echo twig_escape_filter($this->env, $this->getAttribute(($context["release"] ?? null), "distrokid_link", []), "html", null, true);
        echo ">
\t\t\t\t\t\t</div>

\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"flex-row form-buttons\">
\t\t\t\t\t\t<button class=\"button\" type=\"submit\">Save</button>
                        <a href=\"";
        // line 104
        echo call_user_func_array($this->env->getFunction('route')->getCallable(), ["admin::releases"]);
        echo "\" class=\"button back-button\">Back</a>
\t\t\t\t\t</div>
\t\t\t\t</form>
\t\t\t</div>
\t\t</div>
\t";
    }

    public function getTemplateName()
    {
        return "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/admin/releases/viewrelease.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 104,  217 => 98,  210 => 94,  203 => 90,  196 => 86,  189 => 82,  182 => 78,  175 => 74,  169 => 70,  156 => 68,  153 => 67,  150 => 66,  147 => 65,  144 => 64,  140 => 63,  131 => 57,  124 => 53,  112 => 44,  104 => 39,  96 => 34,  88 => 29,  80 => 24,  73 => 20,  65 => 15,  61 => 14,  54 => 10,  51 => 9,  48 => 8,  43 => 6,  40 => 4,  37 => 2,  35 => 1,  29 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% if release %}
\t{% set pageTitle = \"Edit Release\" %}
{% else %}
\t{% set pageTitle = \"New Release\" %}
{% endif %}
{% extends \"_layout/adminsite.twig\" %}

{% block content %}
\t<div class=\"header_content slowload\" data-module=\"slowload\">
\t\t<div class=\"back_img\"><img src=\"{{config('links.s3_img_link')}}releases/backgrounds/cn-back.png\"></div>
\t\t<div class=\"admin_div edit_div flex-column\">

\t\t\t<div class=\"table\">
\t\t\t\t<form class=\"edit_form\" method=\"POST\" action=\"{{route('admin::saverelease',[release.id])}}\">
\t\t\t\t\t        {{ csrf_field()}}
                    <div class=\"y-scroll-div\">
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Release Title:<sup style=\"color:#b31010b8\">*</sup>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<input name=\"title\" required value='{{release.title}}'>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Subtitle:</p>
\t\t\t\t\t\t\t<input name=\"subtitle\" value='{{release.subtitle}}'>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Description:<sup style=\"color:#b31010b8\">*</sup>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<textarea name=\"description\" required>{{release.description}}</textarea>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Release Date: (YYYY-MM-DD)<sup style=\"color:#b31010b8\">*</sup>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<input name=\"release_date\" required placeholder=\"YYYY-MM-DD\" value={{release.release_date}}>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Album Art Img Name:<sup style=\"color:#b31010b8\">*</sup>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<input name=\"img_link\" required value={{release.img_link}}>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Background Type:<sup style=\"color:#b31010b8\">*</sup>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<select name=\"background_type\" required value={{release.background_type}}>
\t\t\t\t\t\t\t\t<option value=\"video\">Video</option>
\t\t\t\t\t\t\t\t<option value=\"image\">Image</option>
\t\t\t\t\t\t\t</select>

\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Background Image Name:<sup style=\"color:#b31010b8\">*</sup>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<input name=\"back_img_link\" required value={{release.back_img_link}}>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Gallery Img Link:</p>
\t\t\t\t\t\t\t<input name=\"gallery_img_link\" value={{release.gallery_img_link}}>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Theme Color:<sup style=\"color:#b31010b8\">*</sup>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t<select name=\"theme_color\" required>
\t\t\t\t\t\t\t\t{% for color in colors %}
\t\t\t\t\t\t\t\t\t{% set selected = '' %}
\t\t\t\t\t\t\t\t\t{% if release.theme_color == color %}
\t\t\t\t\t\t\t\t\t\t{% set selected = 'selected' %}
\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t<option value=\"{{color}}\" {{ selected }}>{{color}}</option>
\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Youtube Link:</p>
\t\t\t\t\t\t\t<input name=\"youtube_link\" value={{release.youtube_link}}>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Spotify Link:</p>
\t\t\t\t\t\t\t<input name=\"spotify_link\" value={{release.spotify_link}}>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>iTunes Link:</p>
\t\t\t\t\t\t\t<input name=\"itunes_link\" value={{release.itunes_link}}>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Youtube Music Link:</p>
\t\t\t\t\t\t\t<input name=\"youtube_music_link\" value={{release.youtube_link}}>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Amazon Link:</p>
\t\t\t\t\t\t\t<input name=\"amazon_link\" value={{release.amazon_link}}>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>iHeartRadio Link:</p>
\t\t\t\t\t\t\t<input name=\"iheartradio_link\" value={{release.iheartradio_link}}>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"form_input_with_label flex-row\">
\t\t\t\t\t\t\t<p>Youtube Link:</p>
\t\t\t\t\t\t\t<input name=\"distrokid_link\" value={{release.distrokid_link}}>
\t\t\t\t\t\t</div>

\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"flex-row form-buttons\">
\t\t\t\t\t\t<button class=\"button\" type=\"submit\">Save</button>
                        <a href=\"{{route('admin::releases')}}\" class=\"button back-button\">Back</a>
\t\t\t\t\t</div>
\t\t\t\t</form>
\t\t\t</div>
\t\t</div>
\t{% endblock %}
", "C:\\Users\\isaac\\Documents\\Projects\\ipm\\resources\\views/admin/releases/viewrelease.twig", "");
    }
}
